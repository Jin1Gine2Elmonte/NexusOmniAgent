# ١٢ — Score Fragments for the First Performance

## Preface

What follows is not a complete score. *al-Yaqqāʿ* has no complete score. What follows is a set of fragments — instructions, notations, prose — for the first performance.

The first performance is specified to last **seven hours**. The seven hours correspond to the deep cycle of the Stratum of the Structure.

The fragments are organized by the work's four (or five) domains, not by time. The score is therefore not a sequence of events but a *territory* that performers enter.

Each fragment specifies:

- The domain.
- The strata involved.
- The gestures available.
- The silences to be witnessed.
- The thefts to be initiated.
- The conditions under which the fragment may occur.

The performers choose which fragments to inhabit, when, and how. The fragments are not obligatory. They are *available*.

---

## Fragment I — The Opening (Opening of the First Performance)

**Domain:** all four (Erasure, Theft, Unsaid, Ancestral) at once. Domain of the Unheard beneath.

**Time:** the first 60 seconds.

**Strata:** all nine strata. None is sounding.

**Instructions:**

> *For sixty seconds, no sound is produced by any performer. The audience is silent. The performance space is silent. The silence is Stage 1 (Birth of Silence). It is fully silent. No breath. No page-turns. No ambient noise above 20 dB.*
>
> *At the end of sixty seconds, the first sound may occur. The first sound is the Stratum of the Child producing a single pitch. The pitch is A=440. The pitch is sustained for one breath (2–7 seconds). The pitch fades to silence.*
>
> *This is the opening.*

**Notes for performers:**

- The first sound is the simplest possible sound. A single pitch.
- It is produced by the Child, the most innocent stratum.
- It does not resolve. It fades.
- It is the first trace of the work.

---

## Fragment II — The Priest's First Sentence (Domain of Erasure)

**Domain:** Erasure. The Domain of Theft, the Unsaid, and the Ancestral are backgrounded.

**Time:** minutes 1 through 17.

**Strata:** Priest (sounding), others (silent or backgrounded).

**Notation (conventional staff notation, with modifications):**

> *The cellist sustains a low tone (open C string, approximately 65 Hz) for 17 minutes. The tone is not attacked; it emerges from silence. The tone does not crescendo or diminuendo. It does not vary in pitch. It does not vary in timbre. The cellist's bow pressure is constant. The cellist's breath (audible through the instrument's resonance) is the only variation.*
>
> *At minute 17, the tone fades to silence over 30 seconds. The fade is not a diminuendo but a withdrawal — as if the tone is leaving the room, not dying in it.*

**Notes for performers:**

- The Priest's first sentence is the work's first long-duration event.
- It is not music. It is presence.
- The cellist may not look at the audience. The cellist looks at the instrument, or at the silence.

---

## Fragment III — The Merchant's First Theft (Domain of Theft)

**Domain:** Theft. The Erasure, Unsaid, and Ancestral domains are backgrounded.

**Time:** sometime between minutes 5 and 23. The exact time is the performer's choice.

**Strata:** Merchant (sounding), Scribe (commenting), others (silent or backgrounded).

**Notation (prose instructions):**

> *The Merchant (clarinetist) initiates a theft. The theft is from a named work chosen by the performer before the performance begins. The theft must be documented in the hidden score before the performance begins.*
>
> *The theft is performed in fragments. The clarinetist plays a 5–10 second fragment, then is silent for 5–15 seconds, then plays another fragment, then is silent. The fragments are not connected. They are not in order. They are taken from the source work in any sequence the performer chooses.*
>
> *After each fragment, the Scribe (speaker) reads a sentence from the hidden score's documentation of the theft. The sentence may be: the name of the source work, the date of the theft, the performer's name, or any other documented element.*
>
> *The Merchant continues initiating fragments until the performer decides to stop. There is no minimum or maximum number of fragments.*

**Notes for performers:**

- The Merchant's theft is the work's first explicit borrowing.
- The borrowing is documented before the performance.
- The borrowing is fragmented and not sequential.
- The Scribe's commentary makes the borrowing audible.

---

## Fragment IV — The Child's Question (Domain of the Unsaid)

**Domain:** Unsaid. Erasure, Theft, and Ancestral are backgrounded.

**Time:** sometime between minutes 3 and 7. Then recurring every 4–7 minutes throughout the performance.

**Strata:** Child (sounding), others (silent).

**Notation (prose):**

> *The Child (child or child-voiced adult) speaks a question. The question is chosen from a list provided in the score, or invented by the performer. The question is spoken once. The question is not answered.*
>
> *The list of available questions includes:*
> - *Why does the city have so many names for the same rain?*
> - *What does silence taste like?*
> - *Where do forgotten songs go?*
> - *Why does the well hear voices that no one speaks?*
> - *Is there a name that no one has ever said?*
>
> *After the question is spoken, the Child is silent for 4–12 seconds. Then the question may be repeated, with slight variation, or a new question may be asked.*

**Notes for performers:**

- The Child's questions are the work's central unsaid.
- The questions are not answered because the work does not contain the answers.
- The questions may recur throughout the performance, accumulating.

---

## Fragment V — The Lover's Long Phrase (Domain of the Ancestral)

**Domain:** Ancestral. Erasure, Theft, and Unsaid are backgrounded.

**Time:** sometime between minutes 23 and 67.

**Strata:** Lover (singing), Priest (backgrounded, sustaining).

**Notation (time-bracket):**

> *Between minute 23 and minute 31, the Lover (singer) initiates a phrase. The phrase may be 60–180 seconds long. The phrase may be in any language, or in no language. The phrase may repeat within itself.*
>
> *Within the phrase, the Lover incorporates material from past performances. For the first performance, this material must be invented — invented documentation of imagined performances.*
>
> *The Lover's phrase is repeated within itself at least three times. Each repetition drifts from the previous. The fourth repetition is unrecognizable from the first.*
>
> *The Lover does not announce the repetition. The audience perceives the repetition, or does not.*

**Notes for performers:**

- The Lover's phrase is the work's first instance of memory.
- For the first performance, the memory is invented.
- The repetition-with-drift is the work's first instance of transformation.

---

## Fragment VI — The Mad's Leap (Domain of Erasure / Domain of the Unsaid)

**Domain:** Erasure and Unsaid foregrounded simultaneously. Theft and Ancestral backgrounded.

**Time:** sometime between minutes 31 and 89. Recurring unpredictably.

**Strata:** Mad (active), others (silent or stunned).

**Notation (graphic):**

> *The Mad (percussionist) initiates a leap. The leap is a sudden, loud sound — a strike, a shout, a cluster attack — preceded by at least 20 seconds of silence in the Mad's stratum.*
>
> *The leap may be visualized as a vertical line on a graphic score. The line begins at the bottom of the page (silence) and rises suddenly to the top (full force). The line is jagged, not straight.*
>
> *After the leap, the Mad is silent for 5–15 seconds. Then the leap may be repeated, transformed.*

**Notes for performers:**

- The Mad's leap is the work's rupture.
- It breaks whatever was happening.
- It is not answered. It is not explained.
- It is forgotten after it occurs.

---

## Fragment VII — The First Seam

**Domain:** all four foregrounded simultaneously.

**Time:** sometime between minutes 45 and 90.

**Strata:** at least three strata sounding simultaneously.

**Notation (prose):**

> *A seam occurs when at least three strata are sounding simultaneously, with their events close enough in time to be perceived as related but not synchronized.*
>
> *The first seam of the first performance is to be initiated by the performers' collective decision. The performers agree (silently, by gesture) on a moment. At that moment, the Priest sustains, the Merchant initiates a fragment, and the Child speaks a question.*
>
> *The seam produces emergent material — sound that is not produced by any single stratum but by the meeting of three. The emergent material is not composed. It is discovered.*
>
> *The seam is documented in the hidden score as the first seam.*

**Notes for performers:**

- The seam is the work's most distinctive event.
- It cannot be repeated identically.
- The audience may or may not perceive it as a seam.
- The hidden score records it.

---

## Fragment VIII — The First Failure

**Domain:** all four foregrounded.

**Time:** sometime between minutes 67 and 134.

**Strata:** Priest, Merchant, Wise, Lover, Mad (all sounding).

**Notation (prose):**

> *The performers attempt a Failed Celebration. The attempt builds toward a moment that the conventions of music would call a climax — increased density, increased dynamic, convergence of multiple strata.*
>
> *The buildup is interrupted before climax. The interruption is initiated by the performer who has been chosen (or has volunteered) to interrupt.*
>
> *The interruption may be: a sudden silence in one stratum, a Mad leap, a Child's question at maximum volume, a Scribe's reading, a theft that fails, a Named Wound that is forgotten, a Missing Book that emerges unexpectedly.*
>
> *After the interruption, the work continues in a different direction. The climactic moment that did not occur becomes part of the work's memory.*

**Notes for performers:**

- The Failed Celebration is the work's central irony.
- It does not succeed.
- It is documented as a failure.
- Future performances may attempt Failed Celebrations differently.

---

## Fragment IX — The Deep Pulse

**Domain:** Unheard.

**Time:** at minute 23. Then every 23 minutes thereafter.

**Strata:** Structure only (often inaudible).

**Notation (technical):**

> *At minute 23, the Structure emits a deep pulse. The pulse is a low sine tone at 23 Hz (below human hearing range for most adults). The tone is sustained for 30 seconds, fading in over 10 seconds and fading out over 20 seconds.*
>
> *The pulse is transmitted through the subwoofer. Most audience members will not hear it. Some will feel it as vibration. The performers, standing near the subwoofer, may hear it.*
>
> *The pulse is repeated every 23 minutes throughout the seven-hour performance. Total pulses: 18 (at minutes 23, 46, 69, 92, 115, 138, 161, 184, 207, 230, 253, 276, 299, 322, 345, 368, 391, 414 — note that the last pulse is at minute 414, near the end of the seven-hour cycle).*
>
> *The pulses are documented in the hidden score as the Structure's self-awareness.*

**Notes for performers:**

- The deep pulses are the work's clock.
- They are mostly inaudible.
- They mark the form's awareness of itself.
- They are not announced.

---

## Fragment X — The Closing

**Domain:** Unsaid foregrounded. Erasure, Theft, Ancestral backgrounded. Unheard beneath.

**Time:** the last 30 minutes of the seven-hour performance.

**Strata:** all nine strata, but mostly silent.

**Notation (prose):**

> *The closing begins when a condition specified in the score is met — typically the completion of the deep cycle, or the performers' collective decision that the work has reached its end.*
>
> *During the closing, most strata are silent. The Priest sustains a tone that fades over 17 minutes. The Child asks one final question. The Lover sings one final phrase that repeats within itself and becomes unrecognizable. The Merchant initiates one final theft, fragmented, that is not completed. The Mad makes one final leap, then is silent. The Dying makes one final fragment, then is silent. The Wise speaks one final maxim. The Scribe reads one final entry from the hidden score. The Structure emits one final deep pulse.*
>
> *After the final pulse, all strata are silent. The silence is Stage 7 (Resurrection of Silence). It lasts no longer than 60 seconds.*
>
> *Then the work ends.*

**Notes for performers:**

- The closing is the work's return to silence.
- It is not a finale. It is a leaving.
- The audience's silence during the closing is part of the work.
- The work ends when the conditions for ending are met.

---

## After the First Performance

After the first performance, the performers:

1. Document the performance (audio, video, written, drawn — any medium).
2. Add to the documentation something that is not strictly true.
3. Update the hidden score with the documentation.
4. Update the deep archive.
5. Forget at least one element of the performance.
6. Lie about the performance to anyone who asks.
7. Plan the next performance (which will be different).

The hidden score, after the first performance, contains:

- The structural skeleton (unchanged).
- The mathematical relations (unchanged).
- The list of the first performance's gestures.
- The list of the first performance's thefts.
- The list of the first performance's seams.
- The list of the first performance's pulses.
- The documentation of what was forgotten.
- The documentation of what was invented.
- The seeds of the next performance.

The next performance reads the hidden score. It forgets some of it. It invents the rest. It performs differently.

The work continues.
