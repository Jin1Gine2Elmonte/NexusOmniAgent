# ٠٩ — Memory and Forgetting

## Definition

The work has memory. The memory is not figurative — it is physical. The hidden score contains the documentation of all past performances. The documentation is the work's memory.

The work also forgets. The forgetting is not absence — it is constitutive. Forgetting removes material from the active score, transforms what remains, and creates conditions for resurrection.

The kernel question Q4 asks: *What makes a person remember what they did not live?*

In the musical work, this question becomes: *What makes the work remember performances that occurred before its current performers were born?*

The answer is: *the hidden score, which is the work's geological memory*.

---

## The Work's Memory Layers

The work has five memory layers:

### Layer 1 — The Active Score

The material currently in use. The gestures, the thefts, the silences, the seams that are available for the current performance.

This layer is what performers may consult. This layer is what audiences may hear.

### Layer 2 — The Documentation of the Last Performance

What happened in the most recent performance. What was played, what was forgotten, what was stolen, what was witnessed.

This layer is read by the Stratum of the Scribe during the current performance (every 60–120 seconds, the Scribe reads from this layer).

### Layer 3 — The Deep Archive

The full documentation of all past performances. The list of all stolen passages. The list of all gestures used. The list of all Named Wounds and their owners.

This layer is never accessed except by the work itself, in cases of resurrection.

### Layer 4 — The Hidden Memory

The structural skeleton. The mathematical relations. The prime-number cycles. The relationships between strata, domains, silences.

This layer is never sounded. It is the work's architecture, invisible to those who inhabit it.

### Layer 5 — The Forgotten

The material that has been completely forgotten — by the performers, by the work, by the audience, by the world.

This layer is preserved in the deep archive but cannot be accessed. It exists as the potential for resurrection. It is the work's unconscious.

---

## How Memory Works in Performance

### The Stratum of the Scribe

The Stratum of the Scribe is the work's primary memory-keeper. During any performance:

- Every 60–120 seconds, the Scribe reads from Layer 2 (the documentation of the last performance).
- The reading is in present tense.
- The reading may be truthful, partially truthful, or invented. The work does not require truthfulness.
- The reading is part of the work. It becomes audible.

The Scribe therefore makes the work's memory audible. The audience hears the work remembering itself.

### The Stratum of the Priest

The Stratum of the Priest is the work's secondary memory-keeper. During any performance:

- Every 17 minutes, the Priest sustains a tone that is also in past performances.
- This tone may be the same pitch, the same duration, the same dynamic.
- The Priest does not announce that it is sustaining a remembered tone. The tone is simply sustained.

The Priest therefore makes the work's memory structural. The audience may or may not notice the remembered tone. The work remembers itself through the Priest's silence and sound.

### The Stratum of the Lover

The Stratum of the Lover is the work's tertiary memory-keeper. During any performance:

- Every 60–180 seconds, the Lover sings a phrase that includes material from past performances.
- The phrase is transformed by the Lover's memory (which may be inaccurate).
- The phrase is repeated within itself, with each repetition drifting further from the original.

The Lover therefore makes the work's memory personal. The audience hears the work remembering itself through desire.

### The Stratum of the Structure

The Stratum of the Structure is the work's deep memory. During any performance:

- Every 23 minutes, the Structure emits a pulse that marks the work's awareness of its own duration.
- Every 4 hours, the Structure emits a cycle that marks the work's awareness of its own age.
- Every 7 hours, the Structure emits a deep cycle that marks the work's awareness of itself as a work.

The Structure therefore makes the work's memory audible as time. The audience does not necessarily hear the pulses. They feel the duration.

---

## How Forgetting Works in Performance

### Performative Forgetting

During a performance, a performer may forget:

- A rule of their stratum.
- A gesture they were about to initiate.
- A theft they were about to perform.
- A Named Wound they were carrying.
- The documentation of the last performance.
- The mathematical relations of the hidden score.

Any of these forgetting-events is part of the work. The forgetting is documented. The documentation enters the hidden score.

### Inherited Forgetting

Performances inherit forgetting from past performances:

- A performer who has never heard the work may perform it. They do not remember what was forgotten. They cannot retrieve it. The work's memory has gaps for them.
- A performer who has performed the work many times may have selective memory. They remember some things and not others. The work's memory is partial for them.
- A performer who has studied the hidden score may have access to material that other performers do not. They remember differently.

The work's memory is therefore not uniform. Different performers have different access. The hidden score contains the *full* memory. The performers contain *partial* memories.

### Documentary Forgetting

Documentation itself forgets:

- Audio recordings degrade.
- Written notes are lost.
- Video recordings lose their color, their sound, their detail.
- Memory itself is unreliable.

The hidden score is therefore also subject to forgetting. The hidden score is updated after every performance. The update may be partial, false, or absent.

The work's memory is therefore subject to three forms of forgetting:

1. Performative forgetting (during the performance).
2. Inherited forgetting (between performances).
3. Documentary forgetting (in the archive).

All three are constitutive.

---

## The Resurrection of Memory

When a forgotten element is resurrected — by the work itself, by accident, by a performer's dream, by an audience member's recognition — it returns to the work in a different form.

A resurrected memory is not the same as the original memory. It has been transformed by forgetting. The transformation may be:

- Partial — only some of the original is recovered.
- Inverted — the opposite of the original is what returns.
- Distorted — the original is present but unrecognizable.
- Augmented — the original has been joined by material that was not in it.
- Fragmented — the original has been broken into pieces.

The resurrection is documented in the hidden score. The documentation notes the form of the resurrection.

---

## What Memory Does to the Work

Memory makes the work *thick*. The work is not what it sounds like at any moment. It is what it sounds like at any moment *plus* what it has sounded like in past performances *plus* what it has forgotten of past performances *plus* what it has invented about past performances.

The work's present is therefore a *geological* present. The audience hears a stratum. Beneath it are older strata. Above it will be future strata. The present moment contains all of them.

This is what the kernel question Q4 demands: that a person remember what they did not live. The work remembers performances its current performers never witnessed. The work is therefore older than its current performers. The work is therefore not young.

---

## What Forgetting Does to the Work

Forgetting makes the work *open*. Without forgetting, the work would be closed — every gesture known, every theft documented, every seam mapped. With forgetting, the work is incomplete. With incompleteness, the work has room for surprise, accident, inheritance, resurrection.

The work therefore needs forgetting. Forgetting is not a failure of memory. Forgetting is the condition under which the work can be inherited.

A tradition that remembers everything cannot inherit. A tradition that forgets selectively *can* inherit, because what is forgotten is available for re-discovery, re-invention, re-statement.

The work forgets selectively. The work inherits. The work is open.

---

## What This Means for Performance

A performance is an act of memory and forgetting. The performer remembers some things, forgets others, invents still others. The performance is therefore not a recovery of the past but an *engagement* with the past, in which the past is partly remembered, partly forgotten, partly invented.

The audience witnesses this engagement. They remember some of it. They forget more of it. They invent the rest. They leave the performance with a memory that is partly true, partly false, partly their own.

The hidden score records all of this. The hidden score is therefore not a record of what happened. It is a record of what was remembered, forgotten, and invented about what happened. It is the work's full memory, including its failures of memory.

The work lives in its memory of itself. The work dies when it forgets itself completely. The work is therefore mortal, like all living things. The hidden score is its attempt to live longer.

---

## What This Means for the First Performance

The first performance has no past performances. Its memory layers are:

- Layer 1 (active score): the score as written.
- Layer 2 (documentation of the last performance): empty. The Scribe reads from the absence of the last performance.
- Layer 3 (deep archive): empty.
- Layer 4 (hidden memory): the full structural skeleton.
- Layer 5 (the forgotten): empty.

The first performance must invent what past performances might have contained. The Scribe reads *what might have been played* — invented documentation of imagined performances.

This is the only case in which invention replaces memory. After the first performance, all subsequent performances have a Layer 2 that is real, not invented.

The first performance is therefore unique in that its memory is entirely fictional. After it, the work's memory is real. The first performance is the work's *prehistory*.
