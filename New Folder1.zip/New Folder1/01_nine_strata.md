# ٠١ — The Nine Strata

## Definition

The work consists of nine concurrent strata (طبقات), each corresponding to one of the nine voice-registers established in `08_voice_registers.md` of the literary foundation. The strata sound simultaneously but do not constitute a coordinated whole. They are not voices in counterpoint. They are not sections of an orchestra. They are *concurrent presences*, each with its own time, its own rules, its own relationship to silence.

The nine strata are not hierarchical. No stratum commands another. No stratum interprets another. They coexist as the city of *Mā Tabqā* coexists — by being there at the same time without acknowledging each other.

The nine strata are not always sounding. Each stratum has its own silence-structure. Some strata are silent for most of a performance. Some are constantly present. The work's texture is determined by which strata are sounding, which are silent, and at what densities.

---

## Stratum 1 — The Priest (الْكَاهِن)

**Material:** sustained tones, low to middle register, ritual pulse, occasional large intervals (4ths, 5ths, 7ths, 9ths).

**Behavior:** breathes every 12 seconds; a phrase every 4 minutes; a "sentence" every 17 minutes.

**Character:** ancient, certain, repetitive. Knows more than it says. Does not wonder. Does not joke.

**Instrumentation (default):** low strings (cello, double bass), bass clarinet, low brass, organ-like sustained tones.

**What it must NOT do:** become a drone; resolve to tonic; accompany another stratum; lead.

**What it must do:** sustain without resolving; repeat without identity; continue without climax.

---

## Stratum 2 — The Merchant (التَّاجِر)

**Material:** speech-rhythm, fragments of melodies that sound like attempts to sell, persuade, seduce. Wide pitch range, episodic, lots of detail.

**Behavior:** phrases of 30–90 seconds; pauses of 5–15 seconds between phrases; sudden changes of register and direction.

**Character:** quick, skeptical, detailed, opportunistic. Knows what he needs to know. Suspects what he doesn't.

**Instrumentation (default):** clarinet, accordion, prepared piano, fast strings (violin), voice (speaking/singing).

**What it must NOT do:** complete a phrase; finish a transaction; become lyrical; achieve sincerity.

**What it must do:** begin and abandon; offer and retract; suspect and move on.

---

## Stratum 3 — The Child (الطِّفل)

**Material:** sparse, simple, intervals of 4ths and 5ths, lots of rests, occasional octave jumps, diatonic, narrow range.

**Behavior:** phrases of 2–7 seconds; rests of 4–12 seconds; occasionally a sudden loud sound (a strike, a shout) without preparation.

**Character:** innocent, questioning, surprised by what is obvious. Does not understand what adults understand. Sometimes understands what adults do not.

**Instrumentation (default):** high register of any instrument (flute, violin harmonics, glockenspiel, voice — children's voice or soprano); toy instruments, simple percussion.

**What it must NOT do:** become cute; become wise; foreshadow; foreshadow adult understanding.

**What it must do:** ask questions without answers; repeat without knowing it is repeating; be silent when others are loud; be loud when others are silent.

---

## Stratum 4 — The Dying (الْمُحتَضَر)

**Material:** fragmented, gasping, breath-sounds, dying away, sudden returns. Sounds that are incomplete. Sounds that stop mid-flight.

**Behavior:** every 8–20 seconds, an event; each event is a fragment, not a phrase; long silences between events.

**Character:** dying but not dead; speaking but not finishing; remembering but not retrieving.

**Instrumentation (default):** voice (whispered, rasping); bowed metal; air through tubes; breath controllers; tape of breath sounds played at low speed.

**What it must NOT do:** become tragic; become melodramatic; sustain; reach resolution.

**What it must do:** stop mid-word; come back unexpectedly; remind that sound is breath; remind that breath ends.

---

## Stratum 5 — The Lover (الْعَاشِق)

**Material:** sustained, lyrical, microtonal inflections (quarter-tones, eighth-tones), long phrases, repetition with variation, ornamentation.

**Behavior:** phrases of 60–180 seconds; phrases overlap with themselves (each phrase begins before the previous ends); repetition within phrases.

**Character:** yearning, repetitive, sees many things in one thing. Confuses present with past with possibility.

**Instrumentation (default):** voice (singing); strings (long tones); winds with microtonal bending; sustained brass; any instrument that can sustain.

**What it must NOT do:** achieve union; complete a phrase cleanly; become sentimental; resolve a dissonance.

**What it must do:** repeat the same interval microtonally differently each time; confuse "I" and "you"; confuse "now" and "then"; make one phrase last four minutes.

---

## Stratum 6 — The Wise (الْحَكِيم)

**Material:** balanced, gnomic, balanced phrases, balanced dynamics. Often speaks in pairs (call-and-response with itself).

**Behavior:** phrases of 30–60 seconds; rests of 5–10 seconds; balanced phrase structure (A-B-A).

**Character:** knows when to be silent. Does not say more than necessary. Speaks in maxims.

**Instrumentation (default):** middle register of any instrument; voice (reciting, not singing); brass (balanced attacks); woodblock (regular pulse).

**What it must NOT do:** become a teacher; lecture; provide moral; dominate another stratum.

**What it must do:** speak briefly and often; use parallel constructions; finish phrases; leave space between phrases.

---

## Stratum 7 — The Mad (الْمَجْنُون)

**Material:** discontinuous, leaping (large registral jumps), cluster attacks, unprepared silences, hallucinatory. Sounds that contradict each other within a single phrase.

**Behavior:** phrases of 5–15 seconds; events of 1–3 seconds within phrases; unpredictable dynamic changes.

**Character:** hears voices others don't hear; sees things others don't see; says things that contradict themselves within a sentence.

**Instrumentation (default):** anything at extremes — piccolo, contrabass, brass at high pressure, percussion at full force; distorted electronics; overblown winds; clusters; multiphonics.

**What it must NOT do:** become violent; become chaotic; lose the sense that there is a stratum at all; align with other strata.

**What it must do:** leap unexpectedly; contradict itself within a phrase; speak the opposite of what it just said; hear voices.

---

## Stratum 8 — The Scribe (النَّاسِخ)

**Material:** speaking voice, present tense, marginal commentary. Often a single voice in stage whisper. Often meta-textual.

**Behavior:** every 60–120 seconds, an utterance; utterances are short (5–15 seconds); utterances are about what is happening or what has happened or what has been forgotten.

**Character:** knows the work is a work; knows it is being performed; knows it will be forgotten; comments anyway.

**Instrumentation (default):** voice (whispered, speaking); the use of any instrument that can speak — recitation, recitation-like passages; occasional instrumental commentary.

**What it must NOT do:** become the dominant stratum; become the audience's guide; resolve the work's questions; promise closure.

**What it must do:** comment on what is happening; note what is missing; note what has been forgotten; note what has been stolen; note what is silent.

---

## Stratum 9 — The Structure (الْبِنْيَة)

**Material:** pure form. Often silence. When it sounds, it sounds like the form itself becoming audible. Sine tones, specific frequencies, mathematically derived durations, prime-number rhythms, structural pulses.

**Behavior:** every 23 minutes, a "deep pulse" — a low, sustained tone at a specific frequency that is inaudible at first but becomes audible over 30 seconds; rarely other sounds; these sounds mark the form's own awareness of itself.

**Character:** no character. The form speaking about itself. The structure as audible thought.

**Instrumentation (default):** sine-tone generators; low-frequency speakers (sometimes below human hearing range); long-attack brass; tubular bells tuned to mathematical ratios; computer-controlled durations.

**What it must NOT do:** become music; become beautiful; become audible by accident.

**What it must do:** be inaudible for long periods; become audible precisely at structural seams; mark the form's self-knowledge; be forgotten as sound and remembered as duration.

---

## The Rules of Simultaneity

1. **No synchronization.** The nine strata do not synchronize. They have different tempos, different phrase-lengths, different breath-rates. They cross at moments called **seams** but do not align.

2. **No hierarchy.** No stratum is more important than another. No stratum accompanies another. No stratum leads.

3. **No blending.** The nine strata do not blend into a unified texture. They are distinct. When they cross, what emerges is not harmony but **interference** — patterns of meeting that are unique to each moment.

4. **Independent silence.** Each stratum has its own silence-structure. Silences in one stratum do not affect silences in another. A seam may occur during a silence in one stratum.

5. **Forgotten strata.** A stratum may be forgotten by the performers (and therefore by the work) for entire performances. When forgotten, it is silent. When remembered, it returns, but with changes.

6. **The Structure is always present.** The Stratum of the Structure is always present, even when inaudible. Its silence is constitutive. Its inaudible pulses are part of the work.

---

## How Strata Become Audible

In performance, the strata become audible through:

- **Concentration** — when a stratum's density increases, it becomes audible.
- **Seams** — when two or more strata cross, the seam itself becomes audible.
- **Theft** — when a stratum borrows material from outside the work, it briefly becomes audible in a different way.
- **Documentation** — when a performer reads past documentation, that stratum's voice becomes audible in the performer.

A stratum is never "introduced." It is always already there.

---

## What This Means for the Work

The work has no melody, no harmony, no orchestration in the conventional sense. It has nine concurrent presences, each with its own character, each with its own time, each with its own silence. The work's "music" is the interference pattern of these presences — the unique texture created at each moment by which strata are sounding, at what density, in what silence, at what time.

This is what the project required. The literary work's nine voices could not have been unified into a symphony. Their simultaneity was always non-harmonic. Their truth was always interference, not resolution.
