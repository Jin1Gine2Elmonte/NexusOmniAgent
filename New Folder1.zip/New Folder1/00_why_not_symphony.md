# ٠٠ — Why a Symphony Cannot Hold This Work

## Why Not a Symphony

A symphony — even an ambitious one, even one aware of its own dissolution (Mahler, late Sibelius, the post-tonal symphony of the 20th century) — is built on seven assumptions that this project cannot honor without betraying itself.

The seven assumptions are:

**1. The conductor–orchestra hierarchy.**
A symphony presupposes a single unifying consciousness that interprets and presents the work. This project's strata (the nine voice-registers of *Mā Tabqā*) have no hierarchy. The Priest does not command the Merchant. The Child does not submit to the Wise. No stratum interprets another. They coexist.

**2. Resolution.**
A symphony resolves — into a tonic, into a final cadence, into a closure that retrospectively justifies the dissonance of what came before. This project's deepest truth is that the name persists *after* its owner is erased. Resolution would falsify that truth.

**3. Fixed duration.**
A symphony has a duration. Even an unusually long one (Mahler's Third) has a duration. This work does not. Its duration is determined by the performers' decision to begin and end, by the conditions of the performance space, by the accidents of the occasion.

**4. The score as complete.**
A symphony's score contains the entire work. What is not in the score is not the work. This work's score contains the work *and* the documentation of all past performances, *and* the gaps that past performances forgot, *and* the material explicitly borrowed from outside. The score is never complete; it grows.

**5. A first performance as the work.**
A symphony, however many times performed, refers back to its first performance as the canonical one. This work has no canonical performance. Each performance is canonical. Each is forgotten.

**6. Passive audience.**
A symphony presupposes an audience that listens while the work happens to them. This project's kernel question Q3 asks whether silence is material. If silence is material, the audience's silence during the performance is part of the work. The audience is implicated.

**7. A single composer.**
A symphony, however collaboratively performed, has a composer. This work has past performers as co-authors of its current state. They have forgotten what they added. The work has forgotten what they forgot. The composer is therefore distributed across all who have touched the work, including those who never heard it.

A symphony violates at least the first six. Therefore a symphony is not the correct form.

---

## What Then?

The form must satisfy eight conditions that the project's foundations make necessary:

### Condition 1 — Stratification, not orchestration
The work's nine voice-registers (Priest, Merchant, Child, Dying, Lover, Wise, Mad, Scribe, Structure) must sound *simultaneously* but not as a coordinated whole. They must be nine concurrent strata. They must not resolve. They must sometimes be silent. They must sometimes be alone.

### Condition 2 — Multiple times, not one
Each stratum must have its own time. The Priest's breath is not the Merchant's tempo. The Child's phrase-length is not the Lover's. These times must cross at moments — "seams" — but must never synchronize. Synchronization would falsify the kernel principle that "the present is thick."

### Condition 3 — Silence as constitutive material
Silence in this work has seven stages (birth, distortion, accumulation, splitting, attenuation, dormancy, resurrection). It is not the absence of sound. It has density, contour, duration, transformation. The work must contain these silences as primary materials.

### Condition 4 — Trace as primary material
The kernel question Q1 ("what remains of the name after its owner is erased?") makes *trace* the work's primary material, not sound. Sound is what survives as trace. The work's primary material is therefore: *what remains of sound after it has stopped sounding*. This is **trace**.

### Condition 5 — Stolen material as constitutive
Q2 ("what makes a story true when stolen from another?") makes *theft* constitutive. The work must contain material explicitly borrowed from other musical works, with the source named. The work must depend on these borrowings. If a borrowed work is forgotten by the world, this work forgets it too. If a borrowed work is remembered by someone, that person enters the work.

### Condition 6 — Memory as physical substrate
Q4 ("what makes a person remember what they did not live?") makes memory not figurative but *physical*. The score contains the documentation of past performances. Each new performance reads that documentation, but with gaps. Each performance forgets some material. The work has a memory of its own forgetting.

### Condition 7 — The hidden score
Q5 ("can this text live if no one reads it?") requires the work to have a hidden score — a score-of-scores that is never performed. This score exists. It is the work's deepest truth. It contains the structural skeleton, the mathematical relations, the list of all stolen passages, the performers' notes. It is never sounded.

### Condition 8 — Optimization for inevitability
The work must be such that no other work could do this. Each choice must follow from the kernel questions. Nothing is decorative. Nothing is for the audience's pleasure. Nothing is for popularity. The work exists because the project required it.

---

## The Form

The form this project demands is named in the lexical engine's kernel:

> **الْيَقَّاع** (*al-Yaqqāʿ*) — "what does not begin or end, but continues."

The full name of the work is therefore:

> **الدَّورة الْيَقَّاع** (*al-Dawr al-Yaqqāʿ*) — "The Perpetual Cycle"

or, in its short form:

> **الْيَقَّاع**

---

## What This Work Is Not

To be unambiguous:

- It is **not** a symphony.
- It is **not** a concerto (no soloist/orchestra hierarchy).
- It is **not** an opera (no characters in the dramatic sense, no narrative arc).
- It is **not** an oratorio (no sacred text).
- It is **not** a string quartet (too many voices).
- It is **not** a song cycle (no fixed text).
- It is **not** ambient music (too active, too demanding).
- It is **not** a graphic score alone (has conventional notation too).
- It is **not** a process piece in the strict sense (the process has multiple concurrent processes).
- It is **not** Cagean indeterminacy (has rules, has strata, has theft).
- It is **not** Satiate repetition (repetition mutates, never returns).

What it is:

It is a **Perpetual Memorial Cycle of Stratified Traces** — a work in which nine concurrent strata, each with its own time, each with its own rules, interweave through silence and theft and forgetting, leaving traces that become the work's only permanent material.

---

## The Path Forward

What follows in this folder is the design of this work. Each file addresses one structural component:

| File | Component |
|---|---|
| `01_nine_strata.md` | The nine concurrent voices/layers |
| `02_time_architecture.md` | Multiple simultaneous times |
| `03_eight_gestures.md` | Symbolic sonic materials |
| `04_seven_silences.md` | Silence as constitutive material |
| `05_four_domains.md` | The four kernel-driven territories |
| `06_hidden_fifth.md` | The score never performed |
| `07_performance_protocol.md` | How performers engage |
| `08_the_stolen.md` | Borrowed material |
| `09_memory_and_forgetting.md` | How the work remembers itself |
| `10_notation.md` | How it is written |
| `11_instrumentation.md` | What plays |
| `12_score_fragments.md` | Score excerpts for the first performance |

Read in order. The order is necessary.
