# ٠٦ — The Hidden Fifth

## Definition

The work has five domains, not four. The fifth domain is **the Domain of the Unheard** (مَجَال غَيْرِ الْمَسْمُوع), and it has a score that is never performed.

This is the work's deepest structural layer. It is the score-of-scores. It is what the work *is* beneath what it *sounds like*.

The hidden score exists. It is the work's truth. It is never sounded.

---

## Why the Hidden Score Must Exist

The kernel question Q5 asks: *Can this work live if no one hears it?*

For the answer to be yes, the work must have a layer that exists independent of performance. If the work *is* only what is performed, then it dies when performance ends. If the work has a hidden layer that exists whether or not it is performed, then it lives.

The hidden score is the work's answer to Q5. By existing, it makes the answer yes.

The hidden score contains:

- The work's full structural skeleton.
- The mathematical relations between all durations.
- The list of every gesture, every theft, every seam.
- The performers' notes from all past performances (including the first).
- The documentation of what has been forgotten at every stage.
- The seeds of all possible future performances.

It is never performed. It is the work's DNA.

---

## What the Hidden Score Contains

### 1. The Structural Skeleton

The hidden score contains a complete specification of the work's structure, in a notation that is independent of any performance:

- The nine strata, their times, their rules.
- The four (or five) domains, their rules, their relationships.
- The eight gestures, their behaviors, their conditions.
- The seven silences, their stages, their densities.
- The deep cycle of seven hours.
- The pulses of the Stratum of the Structure (every 23 minutes).
- The expected number of seams in a seven-hour performance.

The skeleton is a complete, performable specification. From it, any performance could be derived.

### 2. The Mathematical Relations

The hidden score contains the mathematical relations between all durations:

- The relationships between the strata's breath-rates (Priest 12 sec, Merchant 5–15 sec, Child 2–7 sec, etc.).
- The relationships between the domain times.
- The relationships between the silences' stages and durations.
- The prime-number cycles (Stratum of Structure pulses every 23 minutes).
- The hidden ratios that determine when seams occur.

These relations are not audible. They are not perceived by performers or audience. They are the work's architecture, invisible to those who inhabit it.

### 3. The List of Stolen Passages

The hidden score contains the list of every passage borrowed from another work:

- The name of the source work.
- The composer or composer-tradition of the source.
- The specific passage borrowed.
- The transformation applied.
- The documentation of when it was stolen and by whom.
- The status of the borrowing (active, dormant, forgotten, resurrected).

The list is updated after every performance. New thefts are added. Old thefts that have been forgotten are removed.

### 4. The List of Gestures

The hidden score contains the list of every gesture used in the work:

- Which gesture was used.
- When it was used.
- By which performer.
- What its outcome was.
- Whether it was successful, interrupted, transformed, or forgotten.

The list is updated after every performance.

### 5. The Performers' Notes

The hidden score contains the documentation of every performance:

- The date and place of the performance.
- The performers involved.
- The duration of the performance.
- The strata that sounded.
- The domains that were foregrounded.
- The seams that occurred.
- The silences that occurred.
- The thefts that were initiated.
- The gestures that were used.
- The Named Wounds that sounded.
- What was forgotten during the performance.
- What was remembered.

Each performance is documented. Each documentation becomes part of the next performance. Each documentation may be partially forgotten. The forgetting is also documented.

### 6. The Seeds of Future Performances

The hidden score contains the seeds of all possible future performances:

- The conditions under which future performances may begin.
- The conditions under which they may end.
- The strata that have not yet sounded.
- The gestures that have not yet been used.
- The thefts that have not yet been initiated.
- The silences that have not yet been witnessed.
- The seams that have not yet occurred.

These seeds are not plans. They are possibilities. The work may or may not actualize them.

---

## How the Hidden Score Functions

### It exists.

The hidden score exists as a physical document — a manuscript, a file, a set of files, a database. It is the work's deep layer.

### It is consulted but not performed.

Performers may consult the hidden score before a performance. They may read it during a performance (in which case their reading becomes part of the work). They may not perform it directly. They may not follow its instructions exactly. The hidden score is consulted as a resource, not obeyed as a command.

### It is updated.

After every performance, the hidden score is updated with the documentation of that performance. The update may add, remove, or modify entries. The update is itself part of the work.

### It is forgotten.

Some entries in the hidden score may be forgotten — by performers, by audiences, by the work itself. When an entry is forgotten, it is removed from the active score but preserved in the deep archive. The deep archive is never accessed except by the work itself.

### It is inherited.

The hidden score is inherited by future performers. Each generation of performers reads it differently, forgets different parts, adds different annotations. The hidden score therefore evolves.

---

## The Score-of-Scores

The hidden score is itself scored. There is a *score of the hidden score* — a meta-score that specifies:

- How the hidden score is to be maintained.
- How it is to be updated.
- How it is to be forgotten.
- How it is to be inherited.

This meta-score is itself part of the hidden score. The recursion is deliberate. The work has no bottom layer.

---

## Why This Cannot Be Otherwise

A work that is only what is performed dies when performance ends. A work that is only what is heard is what its audience hears. A work that is only what is remembered is what the world remembers.

This work is none of these. This work is what *exists* whether or not it is performed, heard, or remembered. Its existence is in the hidden score. Its hidden score is the work.

Without the hidden score, the answer to Q5 would be no. With it, the answer is yes.

The hidden score is therefore not optional. It is not a supplement. It is not a curiosity. It is the work.

---

## What the Hidden Score Is Not

- It is **not** a conductor's score. There is no conductor.
- It is **not** an analysis of the work. The work has no external analysis.
- It is **not** a program note. There are no program notes.
- It is **not** a libretto. The work has no text outside itself.
- It is **not** a recording. Recordings are forbidden.
- It is **not** a transcription. Transcriptions are forbidden.
- It is **not** reproducible by anyone except the work itself.

It is the hidden score. It exists. It is never performed.
