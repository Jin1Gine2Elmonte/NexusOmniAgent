# ٠٤ — The Seven Silences

## Definition

Silence in this work is not the absence of sound. Silence is *constitutive material* — it has density, contour, duration, transformation, and seven stages of existence.

The literary project's kernel question Q3 asks whether silence is material. In this musical work, the answer is yes, and silence has seven stages.

The seven silences correspond to the seven stages of the myth cycle (birth, distortion, accumulation, splitting, attenuation, dormancy, resurrection), but applied to silence itself.

A silence in this work is specified with:

- **Duration** — how long it lasts.
- **Density** — how filled with non-musical sound it is (breath, ambient noise, page-turns, the Stratum of the Scribe whispering).
- **Contour** — how it changes during its duration (constant, decreasing, increasing, fluctuating).
- **Stage** — which of the seven stages it is in.
- **Strata** — which strata are silent, which are sounding.

---

## Stage 1 — Birth of Silence (وِلَادَة الصَّمْت)

**Character:** Silence as beginning. The work has just begun. Silence is the starting state.

**Behavior:**
- The first silence of a performance is a birth.
- The performers are silent for a specified duration before the first sound.
- This silence is *fully silent* — no ambient sound, no breath, no page-turns.
- The first sound emerges from this silence.

**Density:** zero. The silence is empty.

**Contour:** constant.

**Rules:**
- The first silence cannot be longer than 60 seconds.
- If a performer makes a sound during this silence, the work begins in a different silence.
- The audience's silence during this period is part of the silence.

**What this silence is:** the silence of the city before it had names. The silence of the work before it had sound.

---

## Stage 2 — Distortion of Silence (تَشْوِيه الصَّمْت)

**Character:** Silence that has acquired content. The work has begun; silence is no longer pure.

**Behavior:**
- After the first sound, silences begin to acquire content.
- These silences contain: ambient sound, breath, the sound of instruments not being played (key-clicks, valve-clicks, the rustle of pages).
- The silences are no longer empty.

**Density:** low. The silence has some content.

**Contour:** increasing. The silence becomes more filled over time.

**Rules:**
- Silences in this stage must contain at least one non-musical sound.
- The non-musical sound must be documented (a breath, a page-turn, a chair-creak).
- The non-musical sound must be unintentional or quasi-unintentional. Deliberate "silence sounds" are forbidden here.

**What this silence is:** the silence of the city after the first names fell into the rain. Silence that has begun to *contain*.

---

## Stage 3 — Accumulation of Silence (تَرَاكُم الصَّمْت)

**Character:** Silence that has become heavy. The silences are no longer mere gaps; they are *masses*.

**Behavior:**
- Silences become longer.
- Silences begin to contain musical fragments that have stopped.
- The silences begin to *weigh* on the work.

**Density:** medium. Silences contain residue.

**Contour:** increasing. Silences become heavier.

**Rules:**
- Silences in this stage must be longer than the sounds that precede them.
- A silence in this stage must contain at least one fragment of sound that has been cut off mid-flight.
- The cut-off fragment must be from a different stratum than the silence itself.

**What this silence is:** the silence of names accumulating in the city. The silence of memory that has become heavy.

---

## Stage 4 — Splitting of Silence (اِنْشِطَار الصَّمْت)

**Character:** Silence becomes plural. There is no longer one silence but many.

**Behavior:**
- Multiple silences occur simultaneously.
- Some strata are silent while others sound.
- Within a single stratum, multiple silences occur at different densities.

**Density:** variable. Different silences have different densities.

**Contour:** fluctuating. Silences change.

**Rules:**
- At least two silences must occur simultaneously during this stage.
- The silences must be in different strata.
- A performer can choose which silence they are in.

**What this silence is:** the silence of the city when names began to be plural. The silence of the work when it realized it could not be unified.

---

## Stage 5 — Attenuation of Silence (تَوَهُّن الصَّمْت)

**Character:** Silence becomes almost-sound. The line between silence and sound blurs.

**Behavior:**
- Silences contain more and more sound.
- Sounds become quieter and quieter.
- The distinction between silence and sound becomes impossible to perceive.

**Density:** high. Silence is almost full of sound.

**Contour:** approaching. Sound and silence approach each other.

**Rules:**
- The difference between the loudest sound and the quietest sound in this stage must be no more than 20 dB.
- At least one moment must occur where it is unclear whether what is heard is sound or silence.
- This moment must be documented by the performers.

**What this silence is:** the silence of names becoming almost-sound. The silence of the work becoming almost-music.

---

## Stage 6 — Dormancy of Silence (سُكُوت الصَّمْت)

**Character:** Silence is no longer recognized as silence. The work has forgotten what silence is.

**Behavior:**
- The work continues without acknowledging silence.
- Sound occurs constantly, or near-constantly.
- Silence, if it occurs, is not perceived as silence.
- The audience may believe the work has no silences.

**Density:** maximum. Silence is full.

**Contour:** flat. There is no perceptible silence.

**Rules:**
- The work must contain sound continuously for at least 30 minutes during this stage.
- If a silence occurs, it must be unmarked in the score.
- The performers must not acknowledge the silences that occur in this stage.
- The audience must not be informed of these silences.

**What this silence is:** the silence of names that have been forgotten. The silence of the work that has forgotten itself.

---

## Stage 7 — Resurrection of Silence (بَعْث الصَّمْت)

**Character:** Silence returns, having been forgotten. The silence is different from all previous silences.

**Behavior:**
- A silence occurs that is unmistakably silence.
- This silence is not the same as any previous silence.
- It has no density, no contour, no stage — until it begins, at which point it acquires all of these.
- The silence *remembers itself*.

**Density:** variable. The silence acquires its own density.

**Contour:** unknown. The silence defines itself.

**Rules:**
- This silence must occur after a Stage-6 dormancy of at least 30 minutes.
- This silence must be longer than any silence that occurred in Stage 6.
- After this silence, the work may begin again from Stage 1.
- Or the work may end.
- The work cannot plan when this silence occurs. It occurs when the conditions are right.

**What this silence is:** the silence of names that return from forgetting. The silence of the work that remembers itself.

---

## How Silences Function in Performance

A silence in this work is:

1. **Specified** — the score indicates the conditions for a silence.
2. **Initiated** — a silence begins when its conditions are met.
3. **Staged** — the silence acquires one of the seven stages.
4. **Witnessed** — the silence is documented by the performers.
5. **Forgotten or remembered** — depending on whether it is documented.

The work's seven silences are not sequential. They may occur in any order. They may occur simultaneously in different strata. They may be dormant in one stratum and active in another.

---

## The Relationship Between Silences and Strata

Each stratum has its own silence-architecture:

| Stratum | Default silence stage | Behavior |
|---|---|---|
| Priest | Stage 3 (accumulation) | Heavy silences; silences contain residue |
| Merchant | Stage 4 (splitting) | Multiple silences simultaneously |
| Child | Stage 1 (birth) | Pure silences; silences are beginnings |
| Dying | Stage 7 (resurrection) | Silences that return |
| Lover | Stage 5 (attenuation) | Silences that are almost-sound |
| Wise | Stage 2 (distortion) | Silences with content |
| Mad | Stage 6 (dormancy) | Silences unacknowledged |
| Scribe | Stage 3 (accumulation) | Silences that weigh |
| Structure | All stages | The Structure contains all silences |

---

## What This Means for the Work

The work is not silence and sound. The work is the *interaction* between silence and sound, where silence has seven stages and sound has nine strata. The work's "music" is what emerges when these silences and strata cross, accumulate, attenuate, and resurrect.

The audience's silence during the performance is part of the work. The performers' silences are part of the work. The score's silences are part of the work. The silences that occur between performances are part of the work.

The work is, in this sense, mostly silence. Sound is what happens when silences briefly forget themselves.
