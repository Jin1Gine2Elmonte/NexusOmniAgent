# ٠٥ — The Four Domains

## Definition

The work has four domains (مَجَالات), each corresponding to one of the four kernel questions of the literary foundation. These domains are not movements. They are *territories* that the work inhabits simultaneously throughout any performance.

A conventional symphony has movements that succeed one another in time. This work has domains that *occupy the same time*, layering over one another, intersecting at seams, never resolving.

The four domains are:

1. **Domain of Erasure** (Q1: what remains of the name after its owner is erased?)
2. **Domain of Theft** (Q2: what makes a story true when stolen from another?)
3. **Domain of the Unsaid** (Q3: is there anything in this world no one has told yet?)
4. **Domain of the Ancestral** (Q4: what makes a person remember what they did not live?)

Each domain has its own rules for sound, silence, gesture, and time.

---

## Domain 1 — The Domain of Erasure (مَجَال الْمَحْو)

**Kernel question:** ما الذي يَتبقّى من الاسم بعد أن يُمحى صاحبه؟ (What remains of the name after its owner is erased?)

**Sonic character:** slow, suspended, focusing on disappearance, on what remains.

**Rules:**
- All sounds in this domain must be in some sense *erased* — fading, leaving, becoming trace.
- Sounds in this domain cannot begin. They can only continue, end, or resume.
- The domain prefers *decay* over *attack*.
- The domain prefers *release* over *onset*.
- The domain prefers *diminuendo* over *crescendo*.
- The domain prefers *forgetting* over *remembering*.

**Strata that inhabit this domain:** Priest (always), Dying (often), Structure (always).

**Gestures that belong to this domain:** Mirror (reflections are forms of erasure), Missing Book (silences that are absences), Road (interrupted before reaching target — a form of erasure).

**Silences that belong to this domain:** Stage 1 (birth of silence), Stage 3 (accumulation), Stage 7 (resurrection).

**Time:** the slowest time. The Priest's 17-minute sentences. The Structure's 23-minute pulses.

**Symbolic correspondence:** in the literary work, this is the rain that carries names. Here, it is the sound that carries names — but the names have been erased, leaving only the sound.

---

## Domain 2 — The Domain of Theft (مَجَال السَّرِقَة)

**Kernel question:** ما الذي يَجْعَلُ الْقِصَّةَ تَصْدُقُ إِذَا كَانَتْ مَسْرُوقَةً مِنْ قِصَّةٍ أُخْرَى؟ (What makes a story true when stolen from another?)

**Sonic character:** episodic, multi-temporal, full of explicit borrowings.

**Rules:**
- All material in this domain must be explicitly borrowed from elsewhere or explicitly stolen from within the work itself.
- The domain prefers *quotation* over *original composition*.
- The domain prefers *transformation* over *literal repetition*.
- The domain prefers *attribution* over *concealment*.
- Borrowings must be documented.
- The documentation is part of the work.

**Strata that inhabit this domain:** Merchant (always), Scribe (always), Mad (often).

**Gestures that belong to this domain:** Borrowed Name (always), Named Wound (sometimes — wounds can be stolen), Gate (sometimes — gates can open to stolen territories).

**Silences that belong to this domain:** Stage 4 (splitting), Stage 5 (attenuation).

**Time:** variable. The Merchant's episodic 30–90-second phrases. The Mad's unpredictable 5–15-second leaps.

**Symbolic correspondence:** in the literary work, this is the song of the dead singer, stolen by forty singers. Here, it is the passage from another work, borrowed, transformed, returned.

---

## Domain 3 — The Domain of the Unsaid (مَجَال الْمَسْكُوتِ عَنْهُ)

**Kernel question:** هل يُوجَدُ شَيْءٌ فِي هَذَا الْعَالَمِ لَمْ يُرْوِ أَحَدٌ قِصَّتَهُ بَعْدُ؟ (Is there anything in this world no one has told yet?)

**Sonic character:** sparse, with silence as primary, with attention to what is NOT there.

**Rules:**
- Sound in this domain must be at most 40% of the work's texture. Silence must be at least 60%.
- Sounds in this domain must be *sparse* — long silences between them.
- The domain prefers *absence* over *presence*.
- The domain prefers *what is not said* over *what is said*.
- The performers must be aware of what is not being played at every moment.
- The score documents what is *not* played as much as what is played.

**Strata that inhabit this domain:** Child (always), Scribe (often), Wise (sometimes).

**Gestures that belong to this domain:** Missing Book (always), Broken Chain (the gap is the meaning).

**Silences that belong to this domain:** Stage 2 (distortion), Stage 4 (splitting), Stage 6 (dormancy).

**Time:** the Child's 2–7-second events. The Wise's 30–60-second phrases. The time is punctuated by silence.

**Symbolic correspondence:** in the literary work, this is the scribe's apology — what is not said is more than what is said. Here, the silence is the music.

---

## Domain 4 — The Domain of the Ancestral (مَجَال الْأَجْدَاد)

**Kernel question:** ما الَّذِي يَجْعَلُ الْمَرْءَ يَتَذَكَّرُ مَا لَمْ يَعِشْهُ؟ (What makes a person remember what they did not live?)

**Sonic character:** layered, with quotations from the work's own past.

**Rules:**
- All material in this domain must come from past performances of the work.
- The material may be transformed, but its source must be a past performance.
- The performers may not have access to all past performances.
- Some past performances are forgotten.
- The work contains memory of its own past.

**Strata that inhabit this domain:** Lover (always — lover of the past), Priest (often — keeper of memory), Structure (always — the form's memory of itself).

**Gestures that belong to this domain:** Named Wound (always — wounds are inherited), Mirror (the work's reflection of itself), Road (the path through past performances).

**Silences that belong to this domain:** Stage 3 (accumulation), Stage 7 (resurrection).

**Time:** the Lover's 60–180-second phrases (long enough to contain memories). The Priest's 17-minute sentences.

**Symbolic correspondence:** in the literary work, this is the child who remembers what he did not live. Here, the work remembers what it did not perform.

---

## How the Domains Function in Performance

The four domains are not sections. They are not "movements." They are concurrent territories that the work always occupies.

A single moment of performance may contain elements of all four domains. For example:

- A sound that is borrowed (Domain of Theft) is also a memory of a past performance (Domain of the Ancestral) and is fading (Domain of Erasure) and is being witnessed by a silence (Domain of the Unsaid).

The work's texture at any moment is determined by which domain is *foregrounded* — which is most audible, most evident, most present. The other domains are *backgrounded* — still present, still operating, but less audible.

The score specifies only the conditions under which domains may be foregrounded or backgrounded. The performers determine the actual foregrounding.

---

## The Hidden Fifth Domain — Q5

There is a fifth kernel question, never directly addressed:

> هل يَسْتَطِيعُ هَذَا النَّصُّ أَنْ يَحْيَا إِذَا لَمْ يَقْرَأْهُ أَحَدٌ؟ (Can this text live if no one reads it?)

In the musical work, this corresponds to:

> هل يَسْتَطِيعُ هَذَا الْعَمَلُ أَنْ يَحْيَا إِذَا لَمْ يَسْمَعْهُ أَحَدٌ؟ (Can this work live if no one hears it?)

The fifth domain is the **Domain of the Unheard** (مَجَال غَيْرِ الْمَسْمُوع). It is the domain of the work that exists independent of performance. It is the score-of-scores. It is the unperformed layer.

This domain has its own score (see `06_hidden_fifth.md`). It is never performed. But it is always present in the work.

The Domain of the Unheard contains:

- The work's structural skeleton.
- The mathematical relations between all durations.
- The list of all stolen passages.
- The list of all gestures used.
- The performers' notes from all past performances.
- The documentation of what has been forgotten.

The Domain of the Unheard is the work's deepest truth. The audible work is the surface of the Unheard.

---

## What This Means for the Work

The work is not four things. It is not even five things. It is four (or five) concurrent territories, each with its own rules, each with its own relationship to sound and silence, each inhabited by certain strata.

The work's "music" is the interference pattern of these domains. When the Domain of Erasure crosses with the Domain of Theft, when the Domain of the Unsaid backgrounds the Domain of the Ancestral, when the Domain of the Unheard underlies all four — at these crossings, the work becomes audible in a way that is unique to that moment.

The work cannot be summarized. It cannot be reduced to a theme. It can only be inhabited.
