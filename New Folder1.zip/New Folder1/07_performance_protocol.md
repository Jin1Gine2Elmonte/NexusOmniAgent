# ٠٧ — Performance Protocol

## Definition

A performance of *al-Yaqqāʿ* is an event in which one or more performers attempt to inhabit the work's nine strata, four domains, eight gestures, and seven silences, according to the rules specified in the score and in this protocol.

A performance is not the work. The work is what exists in the hidden score. A performance is an instance of the work's *becoming audible*. Many performances may occur. None of them is canonical.

---

## Beginning

A performance begins when:

1. A performer decides to begin.
2. Or a condition specified in the score is met.
3. Or an event in a past performance triggers a new performance (a remembered phrase, a stolen passage, a forgotten Named Wound).

A performance does not begin with a signal, a downbeat, a conductor's gesture. It begins when one of these conditions occurs. The beginning is therefore often uncertain. The performers may not be sure when the performance has begun. This uncertainty is part of the work.

The first silence of a performance is a Birth-of-Silence silence. It lasts no longer than 60 seconds. The first sound emerges from it.

---

## Who Performs

The work does not specify a fixed ensemble. The performers are:

- Any number of musicians (one or more).
- Any number of speakers (for the Stratum of the Scribe).
- Any number of listeners (the audience is part of the work; see below).

The performers may be:

- Professional musicians.
- Non-musicians.
- People who have never heard the work.
- People who have performed it many times.

The work does not require specific skills. It requires attention to its rules.

### The Performer's Responsibilities

A performer agrees to:

1. **Remember** the rules of the work, including the rules for their stratum.
2. **Forget** at least one thing during the performance. The forgetting is part of the work.
3. **Lie** about what they remember at least once. The lying is part of the work.
4. **Allow** the score to contradict their memory.
5. **Allow** their playing to contradict the score.
6. **Document** the performance (audio, video, written, drawn — any medium).
7. **Add** to the documentation something that is not strictly true. The addition is part of the work.
8. **Update** the hidden score with their documentation, with the understanding that the update will be partially forgotten.

These are the performer's obligations. The work does not enforce them. The work depends on the performer's honesty about dishonesty.

---

## The Audience

The audience is not separate from the work. The audience's silence during the performance is part of the work. The audience's attention, inattention, departures, and re-entries are part of the work.

The audience has the following rights:

1. To listen.
2. To leave.
3. To return.
4. To sleep.
5. To forget.
6. To remember.
7. To lie about having attended.
8. To attend a performance they have forgotten.

The audience's documentation of a performance is as valid as the performers' documentation. The audience's forgetting is as constitutive as the performers' forgetting.

---

## Duration

A performance has no fixed duration. The conditions for ending are:

### Condition 1 — The Performers Decide
A performance ends when all performers agree (silently, by gesture, by ceasing to perform) that the work has ended.

### Condition 2 — The Score Specifies
A performance ends when a condition specified in the score is met (e.g., the Stratum of the Structure has completed one full deep cycle of seven hours; the deep cycle may be longer or shorter in subsequent performances).

### Condition 3 — The Audience Ends It
A performance ends when the audience has completely departed. If even one person remains attentive, the work continues.

### Condition 4 — The Work Ends It
A performance ends when the work itself, through its strata, indicates that it has ended. This indication may be a Failed Celebration that is finally successful, a Resurrection-of-Silence silence, or any other event the work designates as an ending.

### Condition 5 — The Hidden Score Ends It
A performance ends when the hidden score has been completely consulted for that performance. When every relevant entry has been read, the work may end.

A performance may end through any combination of these conditions. A performance that does not end through any of these conditions is *interrupted*. Interruptions are not endings. They are silences that have entered Stage 6 (dormancy).

---

## Documentation

Every performance must be documented. Documentation may take any form:

- Audio recording.
- Video recording.
- Written notes.
- Drawings.
- Body-movement notation.
- Memory (which is then partially forgotten).
- No documentation at all (this is itself a form of documentation — the documentation of absence).

The documentation is added to the hidden score. The documentation may be partial, false, contradictory, or absent. All of these are valid.

The performers are encouraged to document what they *did not* do as much as what they did. The work depends on the documentation of what was not played.

---

## The Performer's First Performance

If a performer has never performed the work before:

1. They must read the score (including the hidden score, if possible).
2. They must forget at least one rule before the performance begins.
3. They must perform their stratum without prior rehearsal with other performers.
4. They must invent at least one gesture that is not in the score.
5. They must lie about their experience of the performance afterward.
6. They must not perform the work again for at least seven hours.

These rules ensure that the first performance is unique, unrepeatable, and partially forgotten before it is documented.

---

## What May Go Wrong

Many things may go wrong. The following are *not* failures but constitutive events:

- A performer forgets their stratum's rules.
- A performer plays at the wrong time.
- A performer plays in the wrong stratum.
- A seam does not occur when expected.
- A silence becomes too long.
- A theft is initiated but not completed.
- A Named Wound is forgotten by its owner.
- The hidden score is not consulted.
- The audience is hostile or asleep.
- The performers quarrel.
- The performance is interrupted by fire, weather, illness, accident.

All of these are part of the work. None of them cancels the performance. The work continues through them. The hidden score records them. Future performances inherit them.

---

## The Last Performance

The work has no last performance. The work may have a *final* performance in a particular tradition, after which that tradition forgets the work. But the work continues in other traditions, in other forms, in other forgotten places.

A tradition that has forgotten the work may, after centuries, rediscover it. The rediscovery is not a "return" — it is a new first performance. The work does not recognize its past performances. Each is canonical. Each is forgotten. Each is remembered differently.

---

## What This Means

A performance of *al-Yaqqāʿ* is not a concert. It is not a ritual in the conventional sense. It is not a happening. It is not an installation. It is an event in which the work becomes audible, briefly, through the strata and silences that have been prepared by the score and the hidden score.

The performers are not interpreters. They are *inhabitants*. They enter the work. They move through it. They forget it. They emerge from it, changed.

The audience is not listeners. They are *witnesses*. They witness what the performers cannot see — the seams, the silences, the failures, the resurrections. They forget what they witnessed. They may remember differently in another performance.

The work is what persists through all performances and all forgetting. The work is the hidden score. The work is the trace.
