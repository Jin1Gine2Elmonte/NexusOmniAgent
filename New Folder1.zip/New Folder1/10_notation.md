# ١٠ — Notation

## Definition

The work uses multiple notation systems, each appropriate to its strata. No single notation can hold the work.

The score is a *composite* document — it contains conventional notation, graphic scores, prose instructions, time-bracket notation, silence notation, theft documentation, and the hidden score (which uses its own notation).

The score is not a single artifact. It is a *set* of artifacts, each in its own medium, each with its own rules of reading.

---

## Notation Systems

### System 1 — Conventional Staff Notation

Used for: Stratum of the Priest, Stratum of the Wise, Stratum of the Lover (when their gestures can be notated).

**Modifications:**
- Noteheads may be replaced with symbols indicating the *behavior* of the note, not its pitch. (For example, a triangle indicating "sustain and decay.")
- Time signatures may be replaced with *breath-marks* indicating the durations of the stratum's breaths.
- Dynamics may include *erasure dynamics* (diminuendo to silence, but with the silence remaining audible).
- Accidentals may include *microtonal* accidentals (quarter-tones, eighth-tones).

**Reading:** Conventional, but with extended vocabulary. A trained musician can read this notation, but must learn the modifications.

---

### System 2 — Time-Bracket Notation (After Cage)

Used for: Stratum of the Merchant, Stratum of the Child, Stratum of the Dying (when their events have variable durations).

**Format:**
- Events are specified by their earliest possible start time and latest possible end time.
- The performer chooses when to start, when to end, and what happens in between.
- The notation specifies *constraints*, not *events*.

**Example (textual description):**
> "Between minute 23 and minute 31, the Merchant may initiate up to four phrases. Each phrase may be 30–90 seconds. Each phrase may be transformed by the performer. Between phrases, silence of 5–15 seconds."

**Reading:** Performer makes choices within constraints.

---

### System 3 — Graphic Scores

Used for: Stratum of the Mad, Stratum of the Dying (when fragments are required), Stratum of the Structure (when its pulses are to be notated).

**Format:**
- Visual shapes on a page.
- The shapes may suggest trajectories, clusters, densities, or behaviors.
- The notation is not symbolic but suggestive.
- The performer interprets the shapes.

**Properties:**
- May be drawn by hand.
- May include text fragments within the shapes.
- May be uninterpretable except by the performer who drew them.
- May include layers of transparency (different strata in different visual layers).

**Reading:** Performer interprets. Audience may see the score during the performance (the score is part of the work's visual presence).

---

### System 4 — Prose Instructions

Used for: Stratum of the Scribe, Stratum of the Structure (when its rules are too complex for notation).

**Format:**
- Written text describing what the stratum should do.
- The text may be read aloud by the performer.
- The text may be whispered.
- The text may be memorized.
- The text may be forgotten and partially recovered.

**Example:**
> "The Scribe, at some point between minute 45 and minute 67, may read the following aloud: 'In the last performance, the Priest sustained a tone for seventeen minutes. The tone was at A=440. In the current performance, the Priest will sustain a tone for seventeen minutes at A=440. The two tones are the same. They are different.'"

**Reading:** Performer reads, whispers, memorizes, forgets, partially recovers.

---

### System 5 — Silence Notation

Used for: All silences, in all stages.

**Format:**
- A silence is notated as a *duration* with *density*, *contour*, *stage*, and *strata*.
- The notation specifies: "From minute X to minute Y, all strata are silent at density Z with contour W in stage V."
- The notation may include: what non-musical sounds are permitted (breath, page-turns, ambient noise).

**Example:**
> "From minute 12:00 to minute 14:30, the Priest, Merchant, and Child are silent at low density with constant contour in Stage 2 (Distortion). Permitted non-musical sounds: breath, page-turns. Forbidden: ambient noise above 30 dB."

**Reading:** Performers observe the silence, document it, witness it.

---

### System 6 — Theft Documentation

Used for: All stolen passages.

**Format:**
- A separate document (or section of the hidden score) that specifies:
  - The source of the theft (named work, named tradition, or named forgotten work).
  - The specific passage stolen.
  - The transformation applied.
  - The performer who initiated the theft.
  - The date and circumstances.
  - The current status.

**Example:**
> "Theft #14. Source: Umm Kulthum, 'Alf Leila wa Leila' (1969), the opening phrase. Transformation: transposed down a major third, fragmented into four segments, each separated by 30 seconds of silence. Performer: [name redacted]. Date: [date redacted]. Status: active."

**Reading:** Hidden score is consulted. Theft is initiated, transformed, performed, documented.

---

### System 7 — The Hidden Score Notation

Used for: The score-of-scores, the structural skeleton, the mathematical relations.

**Format:**
- This notation is not readable by performers. It is the work's private language.
- It may include:
  - Mathematical formulas (durations as functions of other durations).
  - Lists of relations between strata, domains, silences, gestures.
  - Prime-number cycles.
  - Structural diagrams (not visual, but conceptual).
  - Cross-references to other parts of the score.

**Reading:** Only the work itself reads this notation. The performers may consult it, but they do not understand it fully. The hidden score is consulted as an oracle, not a manual.

---

## How the Score Is Used in Performance

### Before the Performance

- Performers read what they can read of the score.
- They consult the hidden score if permitted.
- They forget at least one rule before the performance begins.
- They plan what they will play, knowing that they will not follow the plan exactly.

### During the Performance

- The score is present in the performance space.
- The audience may see the score.
- The performers may consult the score during the performance (this is part of the work).
- The Stratum of the Scribe reads from the score.
- The score is not obeyed; it is inhabited.

### After the Performance

- The score is updated with the documentation of the performance.
- The hidden score is updated.
- The updated score becomes the active score for the next performance.

---

## What the Score Is Not

- It is **not** a conductor's score. There is no conductor.
- It is **not** a complete specification. The work cannot be fully specified.
- It is **not** reproducible. Each copy of the score is unique.
- It is **not** authoritative. The score may be wrong. The performers may correct it.
- It is **not** complete. The score has gaps. The gaps are part of the work.
- It is **not** stable. The score changes after every performance.

---

## The Score as Object

The score has physical presence. It is a set of documents. The documents may include:

- Sheets of paper with conventional notation.
- Sheets of paper with graphic scores.
- Sheets of paper with prose instructions.
- A database for the hidden score.
- Audio recordings of past performances (which may be partially erased).
- Empty pages (for documentation that has not yet been written).
- Pages that have been deliberately erased (for what has been forgotten).

The score is therefore a *physical archive* — a collection of objects that document the work.

The score is also a *performance object*. The performers handle it, read it, fold it, lose it, find it again. The score's physical treatment during a performance is part of the work.

---

## Why Multiple Notations Are Necessary

A single notation cannot hold:

- Conventional pitches AND variable durations AND graphic suggestions AND prose AND silence specifications AND theft documentation AND hidden-score relations.

The work is too multi-dimensional for one notation. The score is therefore a composite — a set of documents, each in its own notation, each with its own logic.

The composite is not unified. The notations do not communicate with each other directly. A passage in conventional notation may be transformed into a graphic score that contradicts the original. This contradiction is part of the work.

The score is therefore not a coherent document. It is a *disagreement* between documents. The work emerges from the disagreement.
