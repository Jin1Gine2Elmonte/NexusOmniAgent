# ٠٢ — Time Architecture

## The Problem

A symphony has one time. Even a non-tonal symphony has one tempo, one conductor, one progression. The work's nine strata cannot share one time without betraying their independence.

The literary project established that there are four times in the work:

- **Event time** — linear, datable, historical.
- **Myth time** — cyclical, always-present, undatable.
- **Narration time** — variable, chosen by the narrator.
- **Reading time** — real-time, unique to each listener/reader.

The musical work must have analogous times — but more, because music has additional temporal dimensions (rhythm, pulse, breath, decay).

---

## Times of the Strata

Each of the nine strata has its own time. These times do not synchronize. They cross only at **seams** (منافصل).

| Stratum | Breath / Pulse | Phrase | Sentence | Deep cycle |
|---|---|---|---|---|
| Priest | 12 sec | 4 min | 17 min | — |
| Merchant | 5–15 sec | 30–90 sec | 5 min | — |
| Child | 2–7 sec | (rare) | — | — |
| Dying | 8–20 sec | (none) | — | — |
| Lover | (none) | 60–180 sec | 8 min | — |
| Wise | 5–10 sec | 30–60 sec | 4 min | — |
| Mad | 1–3 sec | 5–15 sec | 1 min | — |
| Scribe | (none) | 60–120 sec | — | — |
| Structure | (none) | 23 min | 4 hours | 7 hours |

**What this table means:**

The Priest breathes (i.e., has its shortest audible event) every 12 seconds. A phrase is four minutes long. A "sentence" (a complete utterance in the Priest's time) is 17 minutes.

The Child breathes every 2–7 seconds and rarely forms phrases. Its utterances are isolated events.

The Stratum of the Structure has phrases every 23 minutes, "sentences" every four hours, and a deep cycle of seven hours.

No two strata share a duration. No two strata share a phrase length.

---

## The Stratum of the Structure — Special Time

The Stratum of the Structure is the work's deepest time. It operates at three scales:

- **The pulse** (every 23 minutes): a low sine tone, often below hearing range, that becomes audible at the seam.
- **The cycle** (every 4 hours): a complex of inaudible durations that become audible at the structural seams of the performance.
- **The deep cycle** (every 7 hours): the time it takes for the work to "complete" one full circuit — though the work never completes. The first performance of seven hours is one such circuit. Subsequent performances may be longer or shorter; they never *complete* the deep cycle, only *enter* it at different points.

The Stratum of the Structure is the work's clock. Its pulses mark the form's self-awareness. Its cycles mark the time the work has been *living* in a performance.

---

## Seams — Where Times Cross

A **seam** (منفصل) is a moment when two or more strata cross — that is, when their events happen close enough in time that the listener can perceive them as related, but not close enough to be synchronized.

At a seam:

1. The two (or more) strata sound.
2. The listener perceives interference (patterns of beating, harmony, dissonance, rhythm) that is unique to that moment.
3. The seam may produce **emergent material** — sound that is not produced by any single stratum but by the meeting of two or more.

Emergent material is not composed. It is discovered. It cannot be repeated. It is the closest the work comes to "music" in the conventional sense.

A seam is not a climax. It is not a resolution. It is a crossing.

---

## When Seams Occur

Seams occur:

1. **By accident** — when two strata happen to coincide.
2. **By design** — when the score indicates a seam at a specific time.
3. **By theft** — when a stolen passage forces two strata into alignment.
4. **By forgetting** — when a performer forgets to be silent, two strata cross unintentionally.
5. **By documentation** — when a performer reads past documentation aloud, a seam occurs with the Stratum of the Scribe.

Most seams are accidents. The work cannot plan them. It can only create conditions in which they may occur.

---

## The Seven Times of Myth

The work's time also has the seven stages of the myth cycle, applied to time itself:

1. **Birth of time** — the work's time begins.
2. **Distortion of time** — time becomes irregular; events don't match their expected durations.
3. **Accumulation of time** — time becomes heavy; the same moment seems to last longer than its duration.
4. **Splitting of time** — time splits into two times running simultaneously.
5. **Attenuation of time** — time becomes almost still; events are barely distinguishable from silences.
6. **Dormancy of time** — time is no longer perceived as time; the work seems suspended.
7. **Resurrection of time** — time returns, having been forgotten, with differences.

The work moves through these stages. Sometimes multiple stages occur simultaneously in different strata. Sometimes a stage is dormant in one stratum while active in another.

The seven stages of myth time are not the seven stages of the silences (which is a different seven). They are related but distinct. See `04_seven_silences.md`.

---

## The Time of the First Performance

The first performance is specified to last **seven hours**. This is because:

1. The deep cycle of the Stratum of the Structure is seven hours. The first performance will pass through exactly one deep cycle.
2. Seven hours is enough time for all nine strata to enter all four domains (see `05_four_domains.md`).
3. Seven hours is short enough that the audience will not be able to perceive all the work's dimensions. (A work optimized for inevitability is not optimized for full perception in one performance.)
4. Seven hours is long enough that the audience will perceive something. The something is the seam.

---

## How Time is Notated

Time is notated in three ways:

1. **Conventional notation** for strata that have regular pulses (Wise, Priest).
2. **Time-bracket notation** (after John Cage) for strata with variable durations (Merchant, Lover).
3. **Prose instructions** for strata that have no measurable time (Mad, Scribe, Structure).

The score specifies:

- For each stratum, the times of its events.
- For the Stratum of the Structure, the deep pulses (which may be inaudible).
- The expected number of seams in a seven-hour performance.
- The conditions under which the work ends.

The score does NOT specify:

- Which seams will be heard.
- Which strata will sound when.
- What the work will sound like at any given moment.

These are determined by performance.

---

## Time and Memory

Time is also memory. The work's time is its memory of past performances. Each performance reads past documentation at moments specified by the score (every 90 seconds the Scribe reads from documentation; every 4 minutes the Priest sustains a tone that is also in past performances).

The work's time is therefore not empty. It is *stratified*. Each stratum's time contains past strata's times. Each performance contains past performances. The work is therefore *old* — it has the age of all its performances — even when it is being performed for the first time.
