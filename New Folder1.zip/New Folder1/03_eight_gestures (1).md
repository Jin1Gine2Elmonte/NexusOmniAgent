# ٠٣ — The Eight Gestures

## Definition

The work has eight recurring sonic gestures (إيماءات صوتية), each corresponding to one of the eight symbols established in `06_symbolic_reservoir.md` of the literary foundation. These gestures are the work's *motives* — its recurrent sonic materials.

Unlike conventional musical motives, the gestures are not melodic. They are *behaviors of sound*. They specify what sound does, not what sound is.

A gesture is recognized when sound behaves in the specified way. The specific pitch, instrument, and dynamic are not predetermined — only the behavior.

---

## Gesture 1 — The Gate (الْبَوّابَة)

**Definition:** A sound that opens or closes; a threshold crossing.

**Behavior:**
- A sustained tone that rises or holds for a specific duration.
- At the end of the duration, the tone either:
  - **Opens** — continues into another stratum, becoming part of it.
  - **Closes** — returns to silence, ending the gesture.

**Rules:**
- Every Gate has a direction. A Gate can open only forward (toward sound) or backward (toward silence), never both at once.
- A Gate that opens becomes part of the receiving stratum. A Gate that closes returns to its source stratum.
- A Gate's opening or closing is determined by performance, not by the score. The score specifies the Gate; the performer specifies the direction.

**Symbolic correspondence:** the Gate of the literary project — any threshold that can be crossed, including the moment of transition between strata.

---

## Gesture 2 — The Mirror (الْمِرْآة)

**Definition:** Sound that imitates another sound with a specific delay.

**Behavior:**
- A first sound occurs.
- After N seconds (where N is a specific duration for that Mirror), a second sound occurs that imitates the first.
- The imitation may be exact, distorted, partial, inverted, or fragmented.
- The first sound is the "original"; the second sound is its "reflection."

**Rules:**
- The delay N is fixed for that Mirror, but the imitation is not. The reflection may be unrecognizable.
- A Mirror can reflect another Mirror, creating chains of reflections with cumulative distortion.
- The original and its reflection cannot occur in the same stratum. They must be in different strata.
- Mirrors are forbidden from sounding both directions. They only reflect forward.

**Symbolic correspondence:** the Mirror — any surface that reflects. In sound, the surface is time itself.

---

## Gesture 3 — The Broken Chain (السِّلسِلَةُ الْمَكْسُورَة)

**Definition:** Three notes (or three sounds) that don't connect, leaving a gap.

**Behavior:**
- Sound A occurs.
- A gap occurs (silence or different material).
- Sound B occurs.
- A gap occurs.
- Sound C occurs.
- The three sounds are not linked by any perceptible continuity.
- The listener perceives them as related only because of their proximity in time.

**Rules:**
- The gaps must be longer than the sounds.
- The three sounds must be of different durations.
- A Broken Chain is always three sounds. No more, no fewer.
- The gap between B and C must be longer than the gap between A and B.
- The Broken Chain cannot be repeated identically. Each repetition must have different gaps, different sounds.

**Symbolic correspondence:** the broken chain of the literary project — what binds without holding. Here, what links without connecting.

---

## Gesture 4 — The Named Wound (الْجُرْحُ الْمُسَمَّى)

**Definition:** A recurring sonic figure associated with a specific performer or musician.

**Behavior:**
- A specific performer has a specific sonic figure (a small group of pitches, a specific timbre, a specific rhythmic pattern, a specific breath).
- Whenever that performer re-enters the work, this figure returns.
- The figure may evolve over time, but it remains recognizable.
- A Named Wound is *personal*. No two performers share one.

**Rules:**
- Each performer has exactly one Named Wound.
- A Named Wound cannot be performed by anyone but its owner.
- When its owner forgets the Named Wound, the Wound is silent forever.
- A Named Wound may be passed on to another performer, but only through theft (see `08_the_stolen.md`).

**Symbolic correspondence:** the named wound of the literary project — a memory frozen in a name.

---

## Gesture 5 — The Missing Book (الْكِتَابُ الْمَفْقُود)

**Definition:** Silence lasting the duration it would take to read a specific absent text.

**Behavior:**
- The score specifies a text that is *not in the work* — a text that has been removed, forgotten, never written, or exists elsewhere.
- The Missing Book is a silence whose duration equals the time it would take to read that text aloud.
- The duration is fixed; the silence is fixed.
- The text itself is not provided. Only its duration is specified.

**Rules:**
- A Missing Book cannot be filled by another sound. It must remain silent.
- If the text is found (written elsewhere, recovered, rediscovered), the silence is removed and replaced by the text being read aloud.
- If the text is forgotten by everyone, the silence remains indefinitely, becoming a permanent silence.

**Symbolic correspondence:** the missing book of the literary project — a text that waits. Here, the text is not words but a duration.

---

## Gesture 6 — The Road That Doesn't End (الطَّرِيقُ الَّذِي لَا يَنْتَهِي)

**Definition:** A process that approaches conclusion but never reaches it.

**Behavior:**
- A specific process is initiated (a crescendo, a descent, an acceleration, an approach to unison, an approach to a target pitch).
- The process is *interrupted before reaching its target* by silence, by another stratum entering, by theft, or by forgetting.
- The process then begins again, from a different starting point, toward the same (or different) target.
- It is interrupted again.
- And again.
- And again.
- The work may contain many Roads, each approaching a different conclusion.

**Rules:**
- A Road cannot reach its target. The score forbids the final approach.
- A Road that has been attempted seven times without reaching its target is *closed* — it becomes silent forever.
- The interruption may be accidental. The work cannot plan to interrupt its Roads.

**Symbolic correspondence:** the road of the literary project — travel, waiting, being lost.

---

## Gesture 7 — The Borrowed Name (الِاسْمُ الْمُعَار)

**Definition:** Direct quotation from another musical work, with source named.

**Behavior:**
- The score specifies a passage from another work (named in the score).
- The passage is performed by one or more strata, transformed.
- The transformation may include: transposition, instrumentation change, tempo change, fragmentation, addition of silences, removal of notes.
- The source is named; the transformation is documented.
- The Borrowed Name returns to its source after the transformation is complete.

**Rules:**
- Every Borrowed Name must be transformed. Direct quotation is forbidden.
- The transformation must be documented in the score.
- If the source work is forgotten by the world, this work forgets the Borrowed Name too.
- If the source work is remembered by someone, that person becomes part of this work (see `08_the_stolen.md`).

**Symbolic correspondence:** the borrowed name of the literary project — identity, disguise, doubling. Here, the name is a musical phrase from elsewhere.

---

## Gesture 8 — The Failed Celebration (الِاحْتِفَالُ الْفَاشِل)

**Definition:** A moment that should be climactic but isn't.

**Behavior:**
- The score (or the performers) build toward a moment that the conventions of music would call a climax.
- The buildup may involve: increased density, increased tempo, increased dynamic, convergence of multiple strata, lifting of silences.
- The buildup is interrupted before climax.
- What follows is not climax but something else — a return to an earlier state, a sudden silence, an unexpected seam, a Mad leap, a Dying fragmentation.
- The "celebration" fails.

**Rules:**
- A Failed Celebration cannot be repeated. Each attempt is different.
- The score may specify conditions for a Failed Celebration (after N minutes, after M seams, after a specific theft).
- The performers may also initiate a Failed Celebration by their own decision.
- A Failed Celebration that is forgotten becomes a Failed Celebration that succeeded — but the work remembers it failed.

**Symbolic correspondence:** the failed celebration of the literary project — the broken promise, the reversal, the great irony.

---

## How Gestures Function in Performance

A gesture is *initiated* by the score or by a performer's decision. Once initiated, the gesture runs until it completes its behavior. Gestures may overlap. Gestures may interrupt each other. Gestures may be transformed by other gestures.

The work does not contain a sequence of gestures. It contains *conditions under which gestures may occur*. Each performance is a different configuration of initiated gestures.

Some gestures are "rare" — they occur once in a performance, or not at all. Some are "frequent" — they occur many times. The score specifies only the conditions for rarity or frequency, not the occurrences.

---

## What the Gestures Are Not

- They are **not** leitmotifs. They do not represent characters or ideas.
- They are **not** themes. They do not develop, vary, return in altered form.
- They are **not** symbols in the conventional sense. They do not stand for something outside the music.
- They are **not** recognizable to the audience. The audience may not perceive them as such. They are behaviors of sound, perceived only when one is listening for them.

What they are: the work's recurrent behaviors. The work is what it does, not what it sounds like.
