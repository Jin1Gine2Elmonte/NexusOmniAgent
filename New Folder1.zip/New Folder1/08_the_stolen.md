# ٠٨ — The Stolen

## Definition

The work contains material that is explicitly borrowed (stolen) from other musical works, other traditions, other practices. This borrowing is not optional. It is constitutive. Without the stolen, the work would not be the work.

The kernel question Q2 asks: *What makes a story true when stolen from another?*

In the musical work, this question becomes: *What makes a sound true when stolen from another work?*

The answer is: *transformation*.

A stolen passage is true in this work when it has been transformed. A literal quotation is forbidden. The theft must change what is taken, and the change must be documented.

---

## What May Be Stolen

The work may borrow from:

1. **Named individual works** — specific compositions, identified by composer, title, date.
2. **Unnamed traditions** — practices whose origin is unknown or collective (Bedouin singing, Sufi dhikr, Balinese gamelan traditions, etc.).
3. **Forgotten works** — compositions that have been lost, remembered only in fragments.
4. **Future works** — compositions that have not yet been written but may be written.
5. **The work itself** — passages from past performances of *al-Yaqqāʿ*, stolen by current performers.
6. **Non-musical sources** — speech, breath, environmental sound, mathematical relations, natural processes.

The source of each theft is documented in the hidden score. The documentation specifies:

- The name of the source (if known).
- The specific passage stolen.
- The transformation applied.
- The performer who initiated the theft.
- The date and circumstances.
- The current status (active, dormant, forgotten, resurrected).

---

## How Theft Works

### Step 1 — Identification

A performer identifies a passage from outside the work that they wish to steal. The passage may be:

- A specific phrase from a named composition.
- A scale or mode from a tradition.
- A rhythmic pattern from a practice.
- A technique or gesture from an instrument or voice.
- A specific silence from a recording.

### Step 2 — Transformation

The performer transforms the passage. The transformation may include any of:

- Transposition.
- Instrumentation change.
- Tempo change.
- Fragmentation.
- Augmentation.
- Diminution.
- Addition of silences.
- Removal of notes.
- Inversion.
- Retrograde.
- Combination with material from another theft.
- Combination with material from the work itself.

The transformation must be documented in the hidden score. The documentation includes the original and the transformation.

### Step 3 — Performance

The transformed passage is performed. The performance is the theft in action.

### Step 4 — Documentation

After the performance, the theft is documented in the hidden score. The documentation includes:

- What was stolen.
- How it was transformed.
- What happened in the performance.
- Whether the theft was successful (see below).
- Whether the source work was affected (see below).

### Step 5 — Forgetting or Remembering

The theft may be forgotten by the performers. If forgotten, the passage is removed from the active score but preserved in the deep archive. If remembered, the passage remains in the active score.

---

## When Theft Succeeds

A theft succeeds when:

1. The transformation makes the passage unrecognizable to anyone who knows the source.
2. Yet the passage retains a *trace* of the source — a contour, an interval, a rhythm, a silence, a gesture.
3. The trace is documented in the hidden score.
4. The trace is heard (or unheard) in the performance.
5. The audience does not know what was stolen, but they may sense its presence.

A theft that is recognized by an audience member who knows the source *also* succeeds — in this case, the audience member becomes part of the work (see below).

---

## When Theft Fails

A theft fails when:

1. The transformation is so complete that no trace remains.
2. The transformation is so incomplete that the passage is recognizable.
3. The passage is stolen but never performed.
4. The passage is performed but not documented.
5. The source work is forgotten by everyone (including the work itself), making the theft impossible.

A failed theft is documented in the hidden score. It becomes part of the work's archive.

---

## The Audience Member Who Recognizes

If an audience member recognizes a stolen passage — that is, if they identify the source — they become part of the work. Specifically:

1. They are added to the hidden score as a *witness*.
2. Their name (or anonymous designation) is recorded.
3. They are now considered a *co-author* of the work for that performance.
4. Their future performances (if any) may include material from this work.
5. They may not be informed of their new role. The role may be discovered later.

This is one of the work's forms of inheritance. The work inherits its audience, and the audience inherits the work.

---

## What the Stolen Does to the Work

The stolen material changes the work in three ways:

1. **It expands the work.** Each theft adds new material to the work's active palette. The work can sound more things.
2. **It complicates the work.** Each theft adds documentation, transformation, source-relationship. The hidden score grows.
3. **It inherits forgetting.** Each theft is subject to forgetting. The work may forget what it stole. The theft may be removed from the active score.

The work is therefore larger than what it has composed itself to be. It is larger because it has stolen. It is also more fragile, because what it has stolen may be forgotten.

---

## The Stolen That Is Forgotten

If a stolen passage is forgotten — by the performers, by the audience, by the source tradition, by the work itself — the passage is removed from the active score. It becomes part of the deep archive.

The deep archive is never accessed except by the work itself, in cases of resurrection (see Stage 7 silences, `04_seven_silences.md`). When a forgotten passage resurrects, it returns to the active score, transformed by the forgetting.

A passage that has been forgotten and resurrected is not the same passage. It is what that passage became while being forgotten.

---

## What May Not Be Stolen

The following may not be stolen:

1. **The work itself in its entirety.** A performer may not perform the entire hidden score. The hidden score is never performed.
2. **Another performance of the work in its entirety.** A performer may not copy another performance and call it their own. They may steal fragments.
3. **A silence from another tradition.** Silences are too specific to be stolen without distortion. Silences may be borrowed (see below) but not stolen.
4. **A name that belongs to a living person.** Names of living people may be referenced but not stolen.
5. **A silence from the work itself.** Silences within the work may be inherited but not stolen.

---

## The Borrowed (Different from the Stolen)

The work may also *borrow* (without stealing) from:

- Other performances of the work (this is inheritance, not theft).
- The performers' own past work (this is reference, not theft).
- The deep archive of the work (this is resurrection, not theft).

Borrowing is permitted. Stealing is constitutive. The difference: borrowing returns what was taken; stealing does not return what was taken but transforms it.

---

## Why This Cannot Be Otherwise

The work cannot exist without theft. If the work contained only its own material, it would be a closed system. A closed system cannot answer Q2. A closed system cannot have a Domain of Theft. A closed system cannot be inherited by an audience member who recognizes a stolen passage.

The work must therefore contain theft. Theft is constitutive.

The specific thefts are not predetermined. They are determined by performers in their contexts. The work does not specify *what* to steal, only *that* theft must occur and *how* theft must be documented.

---

## What This Means for the First Performance

The first performance of *al-Yaqqāʿ* must include at least:

- Three thefts from named individual works (the works chosen by the performers).
- Two thefts from unnamed traditions.
- One theft from a forgotten work (the work chosen by the performers).
- One theft from the work itself (a fragment from a past performance — for the first performance, this fragment must be invented, as there is no past performance; this is the only exception to the rule that theft of the work requires a past performance).

These thefts must be documented. The documentation becomes part of the hidden score. The first performance is therefore also the first documentation.
