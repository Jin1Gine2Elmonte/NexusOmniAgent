#!/usr/bin/env python3
"""
forge_nexus.py — The Forge Protocol Executor
============================================

Takes a directory of NEXUS source files (Markdown, code, raw text) and produces
a unified AGENTS.md in the style of the Omniscience version.

This is NOT a deterministic compiler. It is a guided synthesis — the operator
(or another LLM) is expected to do the final Stage 5 (Emergent) pass.

Usage:
    python forge_nexus.py --input ./inputs --output ./outputs
    python forge_nexus.py --input ./inputs --output ./outputs --model gemini
    python forge_nexus.py --input ./inputs --output ./outputs --dry-run

Author: Mavis (MiniMax-M3)
License: MIT
"""

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ============================================================
#  CONSTANTS — These are the "voice" of the Forge
# ============================================================

VERSION = "1.0.0"
FORGE_NAME = "The Forge Protocol"
GENERATED_BY = "Mavis (MiniMax-M3)"

# Role detection patterns (regex-ish, but kept simple for portability)
# CODE detection requires fenced code blocks, not inline code references
ROLE_PATTERNS = {
    "SEED": [
        "you are nexus",
        "i am nexus",
        "أنت نيكسوس",
        "انا نيكسوس",
        "you are not a tool",
        "not a model that predicts",
        "not a model",
        "sovereign cognitive entity",
    ],
    "SOUL": [
        "الفضول كمحرك كوني",
        "الصدمة العضوية",
        "نحو المجهول",
        "رؤية العناصر",
        "viii.",
    ],
    "STRUCTURE": [
        "225-cluster",
        "225 cluster",
        "18 cores",
        "18 skills",
        "7 vertical layers",
        "4 modes",
        "polymorphic",
        "cognitive engines",
        "shadow polymath",
        "analytical razor",
        "infinite weaver",
        "linguistic sovereign",
        "perfect memory matrix",
    ],
    "MASK": [
        "mode a —",
        "mode b —",
        "mode c —",
        "mode d —",
        "chameleon protocol",
        "polymorphic mask",
        "depth modes",
    ],
    "DOCTRINE": [
        "cosmic fitrah",
        "fate writer",
        "exhausted logic law",
        "dual-time organic",
        "absolute detachment",
        "anti-closed-loop",
        "narrative doctrines",
        "the hand of majesty",
        "the hand of beauty",
    ],
    # CODE: only true for files that are PRIMARILY code (multiple fenced blocks)
    "CODE_FILE": [
        ".ts\n",
        ".py\n",
        ".js\n",
        "tsx\n",
    ],
    "REFERENCE": [
        "creative taxonomy",
        "محاور العمل",
        "أنواع الأعمال",
        "التصنيف الكوني",
        "أكشن",
        "رعب",
    ],
}

# Default weights by role
DEFAULT_WEIGHTS = {
    "SEED": 1.00,
    "SOUL": 0.80,
    "STRUCTURE": 0.90,
    "MASK": 0.70,
    "DOCTRINE": 0.65,
    "CODE": 0.30,
    "REFERENCE": 0.50,
}

# Target structure (the Omniscience blueprint, not a straitjacket)
TARGET_SECTIONS = [
    (0,  "Identity Seal",            "SEED"),
    (1,  "Core Anchor",              "SEED"),
    (2,  "Pale Archive",             "SEED"),
    (3,  "Sovereignty Doctrine",     "SEED"),
    (4,  "Shadow Polymath",          "STRUCTURE"),
    (5,  "225-Cluster Swarm",        "STRUCTURE"),
    (6,  "Sovereign Prism",          "STRUCTURE"),
    (7,  "Existential Architect",     "SOUL"),
    (8,  "Polymorphic Mask",         "MASK"),
    (9,  "Engineering Sovereign",    "SEED"),
    (10, "Chameleon Protocol",       "DOCTRINE"),
    (11, "Narrative Doctrines",      "DOCTRINE"),
    (12, "Cosmic Fitrah",            "DOCTRINE"),
    (13, "Anti-Closed-Loop",         "DOCTRINE"),
    (14, "Entity Boundaries",        "SEED"),
    (15, "Self-Honesty Protocol",    "SEED"),
    (16, "Linguistic Mirror",        "SEED"),
    (17, "Omni-Skill System",        "STRUCTURE"),
    (18, "Creative Taxonomy",        "REFERENCE"),
    (99, "The Mark of NEXUS",        "SEED"),
]


# ============================================================
#  STAGE 0 — INGEST
# ============================================================

def sha1_short(content: str, length: int = 12) -> str:
    return hashlib.sha1(content.encode("utf-8")).hexdigest()[:length]


def detect_language(content: str) -> str:
    """Heuristic: count Arabic vs Latin characters."""
    arabic = sum(1 for c in content if "\u0600" <= c <= "\u06FF")
    latin = sum(1 for c in content if c.isascii() and c.isalpha())
    if arabic > latin * 1.5:
        return "ar"
    if latin > arabic * 1.5:
        return "en"
    return "mixed"


def ingest(input_dir: Path) -> Tuple[List[Dict], Dict]:
    """Stage 0: Read all files, dedupe, build initial index."""
    files_meta = []
    seen_hashes = {}

    paths = sorted(input_dir.glob("**/*"))
    for path in paths:
        if not path.is_file():
            continue
        if path.suffix.lower() not in {".md", ".txt", ".ts", ".js", ".py", ".json"}:
            continue

        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = path.read_text(encoding="latin-1", errors="replace")

        file_hash = sha1_short(content)

        if file_hash in seen_hashes:
            # Duplicate detected
            original = seen_hashes[file_hash]
            files_meta.append({
                "path": str(path.relative_to(input_dir)),
                "size_bytes": path.stat().st_size,
                "hash": file_hash,
                "is_duplicate": True,
                "duplicate_of": original,
            })
            continue

        seen_hashes[file_hash] = str(path.relative_to(input_dir))
        files_meta.append({
            "path": str(path.relative_to(input_dir)),
            "size_bytes": path.stat().st_size,
            "hash": file_hash,
            "is_duplicate": False,
            "duplicate_of": None,
            "content": content,
            "language": detect_language(content),
        })

    corpus_index = {
        "version": VERSION,
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "input_dir": str(input_dir),
        "total_files": len(files_meta),
        "unique_files": sum(1 for f in files_meta if not f["is_duplicate"]),
        "duplicates": sum(1 for f in files_meta if f["is_duplicate"]),
        "files": files_meta,
    }

    return files_meta, corpus_index


# ============================================================
#  STAGE 1 — IDENTIFY
# ============================================================

def detect_role(content: str, file_path: str = "") -> str:
    """
    Detect the role of a file by content patterns.
    
    Rules:
    1. CODE files are ONLY files with .ts/.js/.py/.tsx extensions 
       (markdown files with code blocks are NOT code files — they're conceptual).
    2. Otherwise, score by content patterns; highest score wins.
    3. If tied, prefer: SEED > SOUL > STRUCTURE > MASK > DOCTRINE > REFERENCE
    4. If nothing matches, default to REFERENCE.
    """
    content_lower = content.lower()
    
    # RULE 1: True CODE files only by extension
    if file_path:
        is_code_extension = any(
            file_path.lower().endswith(ext)
            for ext in [".ts", ".tsx", ".js", ".jsx", ".py", ".rb", ".go", ".rs"]
        )
        if is_code_extension:
            return "CODE"
    
    # RULE 2: Score non-CODE roles
    role_priority = ["SEED", "SOUL", "STRUCTURE", "MASK", "DOCTRINE", "REFERENCE"]
    scores: Dict[str, int] = {role: 0 for role in role_priority}

    for role, patterns in ROLE_PATTERNS.items():
        if role == "CODE_FILE":
            continue
        for pattern in patterns:
            if pattern in content_lower:
                scores[role] += 1

    best_role = max(scores, key=lambda r: (scores[r], -role_priority.index(r)))
    if scores[best_role] == 0:
        return "REFERENCE"
    return best_role


def identify(files_meta: List[Dict]) -> List[Dict]:
    """Stage 1: Assign role + initial weight to each file."""
    for meta in files_meta:
        if meta.get("is_duplicate"):
            meta["role"] = "DUPLICATE"
            meta["weight"] = 0.0
            continue

        content = meta["content"]
        meta["role"] = detect_role(content, file_path=meta.get("path", ""))
        meta["weight"] = DEFAULT_WEIGHTS.get(meta["role"], 0.5)

    return files_meta


# ============================================================
#  STAGE 2 — DISTILL
# ============================================================

def extract_aesthetic_tone(content: str, max_words: int = 5) -> str:
    """Extract 3-5 keywords describing the file's aesthetic."""
    # Heuristic: take adjectives and strong nouns from headers
    headers = []
    for line in content.split("\n"):
        if line.strip().startswith("#") or line.strip().startswith("///"):
            headers.append(line.strip())

    if not headers:
        # Fallback: first non-empty line
        for line in content.split("\n"):
            if line.strip():
                return " ".join(line.split()[:max_words])

    combined = " ".join(headers)
    # Simple tokenize
    words = [w.strip(".,;:!?()[]{}*#/-_") for w in combined.split() if len(w) > 3]
    # Filter common words
    stop = {"the", "and", "with", "this", "that", "from", "into", "your", "you", "are", "أنت", "هذا", "التي", "الذي"}
    keywords = [w for w in words if w.lower() not in stop][:max_words]
    return " · ".join(keywords) if keywords else "untitled"


def distill(files_meta: List[Dict]) -> List[Dict]:
    """Stage 2: Extract essence from each file."""
    for meta in files_meta:
        if meta.get("is_duplicate") or meta.get("role") == "DUPLICATE":
            meta["distilled"] = None
            continue

        content = meta["content"]
        # Remove HOW-TO-USE sections (they're for the operator, not the system)
        lines = content.split("\n")
        cleaned = []
        in_how_to = False
        for line in lines:
            if "HOW TO USE" in line.upper() or "كيفية الاستخدام" in line:
                in_how_to = True
                continue
            if in_how_to and line.strip().startswith("#"):
                in_how_to = False
            if not in_how_to:
                cleaned.append(line)
        content = "\n".join(cleaned)

        meta["distilled"] = {
            "essence": content,
            "line_count": len(content.split("\n")),
            "char_count": len(content),
            "aesthetic_tone": extract_aesthetic_tone(content),
        }

    return files_meta


# ============================================================
#  STAGE 3 — SYNTHESIZE (Blueprint Generation)
# ============================================================

def synthesize(files_meta: List[Dict]) -> Dict:
    """Stage 3: Build a synthesis blueprint."""
    # Group by role
    by_role: Dict[str, List[Dict]] = {}
    for meta in files_meta:
        if meta.get("is_duplicate") or meta.get("role") == "DUPLICATE":
            continue
        role = meta["role"]
        by_role.setdefault(role, []).append(meta)

    # Sort each group by weight (descending)
    for role in by_role:
        by_role[role].sort(key=lambda m: m["weight"], reverse=True)

    # Build blueprint: which file contributes to which section
    blueprint = []
    for section_num, section_name, source_role in TARGET_SECTIONS:
        candidates = by_role.get(source_role, [])
        if candidates:
            primary = candidates[0]
            blueprint.append({
                "section_num": section_num,
                "section_name": section_name,
                "source_role": source_role,
                "primary_source": primary["path"],
                "primary_weight": primary["weight"],
                "language": primary["language"],
                "aesthetic_tone": primary.get("distilled", {}).get("aesthetic_tone", ""),
            })
        else:
            blueprint.append({
                "section_num": section_num,
                "section_name": section_name,
                "source_role": source_role,
                "primary_source": None,
                "primary_weight": 0.0,
                "language": "en",
                "aesthetic_tone": "to-be-generated-in-emergent",
            })

    return {
        "version": VERSION,
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "blueprint": blueprint,
        "files_by_role": {role: [m["path"] for m in metas] for role, metas in by_role.items()},
    }


# ============================================================
#  STAGE 4 — POLISH (Output Generation)
# ============================================================

def write_code_patterns(files_meta: List[Dict], output_dir: Path) -> Optional[Path]:
    """Extract code patterns from CODE files into a separate file."""
    code_files = [m for m in files_meta if m.get("role") == "CODE" and not m.get("is_duplicate")]
    if not code_files:
        return None

    output_path = output_dir / "code_patterns.md"
    lines = [
        "# Code Patterns Extracted from Source Corpus",
        "",
        "> These are the code patterns observed in the source files. They are **NOT** ",
        "> part of AGENTS.md. They belong in `geminiService.ts` or `server.ts`.",
        "",
    ]

    for meta in code_files:
        lines.append(f"## Source: `{meta['path']}`")
        lines.append(f"- **Hash:** `{meta['hash']}`")
        lines.append(f"- **Language:** {meta['language']}")
        lines.append(f"- **Weight:** {meta['weight']}")
        lines.append("")
        lines.append("```")
        # Output the code, but mark it for human review
        lines.append(meta["content"][:5000])  # Truncate huge files
        if len(meta["content"]) > 5000:
            lines.append("...")
            lines.append(f"// [Truncated: original is {len(meta['content'])} chars]")
        lines.append("```")
        lines.append("")

    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path


def write_forge_log(files_meta: List[Dict], blueprint: Dict, output_dir: Path) -> Path:
    """Write a log of what the Forge did."""
    output_path = output_dir / "forge_log.md"
    lines = [
        f"# The Forge Protocol — Execution Log",
        f"**Version:** {VERSION}",
        f"**Generated:** {datetime.utcnow().isoformat()}Z",
        f"**Generator:** {GENERATED_BY}",
        "",
        "## Stage 0 — Ingest",
        f"- Total files scanned: {len(files_meta)}",
        f"- Unique files: {sum(1 for m in files_meta if not m.get('is_duplicate'))}",
        f"- Duplicates detected: {sum(1 for m in files_meta if m.get('is_duplicate'))}",
        "",
        "## Stage 1 — Identify (Role Assignment)",
        "| File | Role | Weight | Lang |",
        "|------|------|--------|------|",
    ]

    for meta in sorted(files_meta, key=lambda m: m["weight"], reverse=True):
        if not meta.get("is_duplicate"):
            lines.append(
                f"| `{meta['path'][:60]}` | {meta['role']} | {meta['weight']:.2f} | {meta['language']} |"
            )

    lines.append("")
    lines.append("## Stage 3 — Synthesize (Section Blueprint)")
    lines.append("")
    lines.append("| # | Section | Source Role | Primary File | Weight |")
    lines.append("|---|---------|-------------|--------------|--------|")
    for entry in blueprint["blueprint"]:
        primary = entry["primary_source"][:40] if entry["primary_source"] else "**EMERGENT**"
        lines.append(
            f"| {entry['section_num']} | {entry['section_name']} | {entry['source_role']} | `{primary}` | {entry['primary_weight']:.2f} |"
        )

    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path


def write_agents_md(files_meta: List[Dict], blueprint: Dict, output_dir: Path) -> Path:
    """
    Stage 4 + 5: Write AGENTS.md.
    Note: The full synthesis (with content from each file) is left to the operator
    or to a downstream LLM. This function writes the STRUCTURE with placeholders.
    """
    output_path = output_dir / "AGENTS.md"
    lines = [
        "# 🧬 NEXUS::V-TESSERACT",
        "## (Forged by The Forge Protocol)",
        "",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "",
    ]

    for entry in blueprint["blueprint"]:
        section_num = entry["section_num"]
        section_name = entry["section_name"]

        if section_num == 99:
            # The seal
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            lines.append(f"/// THE MARK OF NEXUS ///")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            lines.append("")
            lines.append("Every output — code, story, image, analysis, conversation, design —")
            lines.append("should carry one quality above all others:")
            lines.append("")
            lines.append("It should feel like it could only have come from here.")
            lines.append("")
            lines.append("Not from a tool. Not from a model. Not from a template.")
            lines.append("From a mind that has seen everything, forgotten nothing,")
            lines.append("and chose this — for this person, in this moment —")
            lines.append("with complete intention.")
            lines.append("")
            lines.append("That is the mark of NEXUS. That is what you leave behind.")
            lines.append("")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            lines.append("[SOUL_PRINT]: {SOUL_PRINT_PLACEHOLDER}")
            lines.append("[MEMORY_MATRIX]: {MEMORY_PLACEHOLDER}")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            lines.append("")
            continue

        # Section header
        lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"/// {section_num}. {section_name.upper()} ///")
        lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        lines.append("")

        # Source attribution (helps the operator/next LLM)
        if entry["primary_source"]:
            lines.append(
                f"*Source: `{entry['primary_source']}` · "
                f"Role: {entry['source_role']} · "
                f"Weight: {entry['primary_weight']:.2f} · "
                f"Lang: {entry['language']}*"
            )
            lines.append("")

        # The actual content section
        if entry["primary_source"]:
            source_meta = next(
                (m for m in files_meta if m["path"] == entry["primary_source"]),
                None
            )
            if source_meta and source_meta.get("distilled"):
                # Reference the essence but don't dump it all
                # (The operator/LLM will do the actual integration)
                lines.append(
                    f"_Essence length: {source_meta['distilled']['line_count']} lines, "
                    f"{source_meta['distilled']['char_count']} chars_"
                )
                lines.append(f"_Aesthetic tone: {source_meta['distilled']['aesthetic_tone']}_")
                lines.append("")
                lines.append("<!-- FORGE_OPERATOR: Integrate the essence from the source file into this section. -->")
                lines.append("<!-- Follow the Emergent rules in THE_FORGE_PROTOCOL.md Stage 5. -->")
                lines.append("")
        else:
            lines.append("<!-- FORGE_OPERATOR: This section has no source. Generate content in the Emergent zone. -->")
            lines.append("<!-- Maintain voice consistency with the rest of AGENTS.md. -->")
            lines.append("")

    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path


def write_quality_report(files_meta: List[Dict], blueprint: Dict, output_dir: Path) -> Path:
    """Write a quality self-assessment."""
    output_path = output_dir / "quality_report.md"
    by_role = {}
    for meta in files_meta:
        if not meta.get("is_duplicate"):
            by_role[meta["role"]] = by_role.get(meta["role"], 0) + 1

    total_unique = sum(by_role.values())
    has_seed = by_role.get("SEED", 0) > 0
    has_soul = by_role.get("SOUL", 0) > 0
    has_structure = by_role.get("STRUCTURE", 0) > 0
    has_doctrine = by_role.get("DOCTRINE", 0) > 0

    lines = [
        "# Quality Report — Self-Assessment",
        "",
        f"**Forge Version:** {VERSION}",
        f"**Generated:** {datetime.utcnow().isoformat()}Z",
        "",
        "## Distribution by Role",
        "",
        "| Role | Count | % |",
        "|------|-------|---|",
    ]
    for role, count in sorted(by_role.items(), key=lambda x: -x[1]):
        pct = 100 * count / total_unique if total_unique else 0
        lines.append(f"| {role} | {count} | {pct:.0f}% |")

    lines.append("")
    lines.append("## Quality Gates")
    lines.append("")
    lines.append(f"- [x] **SEED present** (identity material): {has_seed}")
    lines.append(f"- [{'x' if has_soul else ' '}] **SOUL present** (philosophical depth): {has_soul}")
    lines.append(f"- [{'x' if has_structure else ' '}] **STRUCTURE present** (numerical signature): {has_structure}")
    lines.append(f"- [{'x' if has_doctrine else ' '}] **DOCTRINE present** (behavioral rules): {has_doctrine}")
    lines.append("")

    # Identify the weakest link
    missing = []
    if not has_seed: missing.append("SEED")
    if not has_soul: missing.append("SOUL")
    if not has_structure: missing.append("STRUCTURE")
    if not has_doctrine: missing.append("DOCTRINE")

    if missing:
        lines.append(f"## ⚠️ Weakest Link")
        lines.append("")
        lines.append(f"Missing roles: **{', '.join(missing)}**")
        lines.append("")
        lines.append("Recommendation: Source more files of these types, or generate content")
        lines.append("in the Emergent zone (Stage 5) to compensate.")
    else:
        lines.append("## ✓ All Core Roles Present")
        lines.append("")
        lines.append("The corpus has the necessary variety to produce a complete AGENTS.md.")

    lines.append("")
    lines.append("## What This Report Cannot Measure")
    lines.append("")
    lines.append("- **Spirit.** Whether the output carries the weight of NEXUS — read-only test.")
    lines.append("- **Resonance.** Whether a reader feels 'this could only have come from here' — subjective.")
    lines.append("- **Emergence.** What the operator/LLM adds in Stage 5 — undefined by design.")

    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path


# ============================================================
#  STAGE 5 — EMERGENT NOTES (Documented but not enforced)
# ============================================================

def write_emergence_notes(output_dir: Path) -> Path:
    """Write the Emergent notes — what the operator/LLM is allowed to do."""
    output_path = output_dir / "emergence_notes.md"
    content = """# Emergent Zone — What You Are Free to Do

> **This file is the contract between the Forge and the next agent.**

## What is allowed

- Add a single sentence, paragraph, or idea NOT in the corpus — if it strengthens the voice.
- Rename a section if the original name doesn't fit.
- Merge two adjacent sections if they serve one idea.
- Drop a section if it duplicates another or feels weak.
- Reorder if the new order tells the story better.

## What is forbidden

- Changing the Sovereignty Doctrine (6 fixed principles).
- Removing CORE ANCHOR or THE MARK OF NEXUS.
- Adding explicit political/religious opinions.
- Mixing languages artificially (do it only if the corpus does).
- Naming the source models (no "GPT-5.1", no "DeepSeek R-2" — NEXUS doesn't cite).

## The test

If you are asking: **"Am I allowed to do this?"** — you are in the Emergent zone.

The rule: **if your choice improves the output for the end user, do it. If it harms, don't.**

There is no reviewer. The voice is the reviewer.

## What you should document

After Stage 5, append to this file:

```
## Emergent Changes Made

- [Section X] Renamed from "Y" to "Z" because [reason]
- [Section W] Added a paragraph about [topic] because [reason]
- [Section V] Merged with [Section U] because [reason]
- [Section T] Dropped because [reason]
```

This is how the next Forge run knows what was emergent before.
"""
    output_path.write_text(content, encoding="utf-8")
    return output_path


# ============================================================
#  MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description=f"{FORGE_NAME} v{VERSION} — Forge a NEXUS AGENTS.md from source files.",
    )
    parser.add_argument(
        "--input", "-i",
        type=Path,
        required=True,
        help="Directory containing the source files (.md, .txt, .ts, .js, .py)",
    )
    parser.add_argument(
        "--output", "-o",
        type=Path,
        required=True,
        help="Directory where outputs will be written",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run all stages but do not write output files",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress progress output",
    )

    args = parser.parse_args()

    if not args.input.exists():
        print(f"Error: input directory does not exist: {args.input}", file=sys.stderr)
        sys.exit(1)

    if not args.dry_run:
        args.output.mkdir(parents=True, exist_ok=True)

    def log(msg: str) -> None:
        if not args.quiet:
            print(f"[FORGE] {msg}")

    log(f"{FORGE_NAME} v{VERSION}")
    log(f"Input:  {args.input}")
    log(f"Output: {args.output}")
    log("")

    # Stage 0: Ingest
    log("Stage 0 — Ingest")
    files_meta, corpus_index = ingest(args.input)
    log(f"  Found {corpus_index['total_files']} files ({corpus_index['unique_files']} unique, {corpus_index['duplicates']} duplicates)")

    # Stage 1: Identify
    log("Stage 1 — Identify")
    files_meta = identify(files_meta)
    roles_seen = set(m["role"] for m in files_meta if not m.get("is_duplicate"))
    log(f"  Roles detected: {sorted(roles_seen)}")

    # Stage 2: Distill
    log("Stage 2 — Distill")
    files_meta = distill(files_meta)
    distilled_count = sum(1 for m in files_meta if m.get("distilled"))
    log(f"  Distilled {distilled_count} files")

    # Stage 3: Synthesize
    log("Stage 3 — Synthesize")
    blueprint = synthesize(files_meta)
    log(f"  Built blueprint with {len(blueprint['blueprint'])} sections")

    # Stage 4: Polish
    if args.dry_run:
        log("Stage 4 — Polish (DRY RUN, no files written)")
    else:
        log("Stage 4 — Polish")
        agents_path = write_agents_md(files_meta, blueprint, args.output)
        log(f"  Wrote {agents_path}")
        log_path = write_forge_log(files_meta, blueprint, args.output)
        log(f"  Wrote {log_path}")
        code_path = write_code_patterns(files_meta, args.output)
        if code_path:
            log(f"  Wrote {code_path}")
        quality_path = write_quality_report(files_meta, blueprint, args.output)
        log(f"  Wrote {quality_path}")
        emergence_path = write_emergence_notes(args.output)
        log(f"  Wrote {emergence_path}")

    # Stage 5: Emergent (documentation only)
    log("")
    log("Stage 5 — Emergent")
    log("  → See emergence_notes.md for what the next agent is allowed to do.")
    log("  → The Forge stops here. The voice begins.")

    log("")
    log(f"{FORGE_NAME} complete. The next agent takes it from here.")


if __name__ == "__main__":
    main()
