# NEXUS — TemporalDimension مُصلَحة
# استبدال substring matching بـ semantic search حقيقي
# يستخدم Gemini Embeddings API الفعلي — لا وصفاً شعرياً

---

## المشكلة التقنية الدقيقة في الكود الأصلي

```typescript
// الكود القديم — مطابقة نصية سطحية
async recall(context: string): Promise<string[]> {
  return this.memories
    .filter(m => context.toLowerCase().includes(m.content.toLowerCase().substring(0, 20)))
    .map(m => m.content)
    .slice(0, 5);
}
```

هذا يفشل في حالات بسيطة جداً:
- ذاكرة: "المستخدم يفضل الشرح المباشر بلا مقدمات"
- سياق جديد: "اشرح لي هذا بسرعة من فضلك"
- النتيجة: لا تطابق — لأن أول 20 حرفاً من الذاكرة لا تظهر حرفياً في السياق الجديد

المطابقة النصية لا تفهم المعنى — فقط الحروف المتطابقة حرفياً.

---

## الحل — Semantic Search باستخدام Gemini Embeddings

```typescript
import { GoogleGenAI } from "@google/genai";
import fs from 'fs/promises';
import path from 'path';

interface MemoryRecord {
  id: string;
  content: string;
  embedding: number[];
  timestamp: number;
  confidence: number;
}

export class TemporalDimension {
  private identity: NexusIdentity;
  private ai: GoogleGenAI;
  private memoryPath: string;
  private memories: MemoryRecord[] = [];
  private embeddingModel = 'text-embedding-004';

  constructor(identity: NexusIdentity, ai: GoogleGenAI, memoryPath: string) {
    this.identity = identity;
    this.ai = ai;
    this.memoryPath = memoryPath;
    this.loadMemories();
  }

  private async loadMemories(): Promise<void> {
    try {
      const data = await fs.readFile(this.memoryPath, 'utf-8');
      this.memories = JSON.parse(data);
    } catch {
      this.memories = [];
    }
  }

  // توليد embedding حقيقي للنص
  private async embed(text: string): Promise<number[]> {
    try {
      const result = await this.ai.models.embedContent({
        model: this.embeddingModel,
        contents: text,
      });
      return result.embeddings?.[0]?.values || [];
    } catch (error) {
      console.error('[TEMPORAL] Embedding failed:', error);
      return [];
    }
  }

  // التشابه الكوني (Cosine Similarity) — قياس رياضي حقيقي للمعنى
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length === 0 || b.length === 0 || a.length !== b.length) return 0;

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    const denominator = Math.sqrt(normA) * Math.sqrt(normB);
    return denominator === 0 ? 0 : dotProduct / denominator;
  }

  // نيكسوس يتعلم من التجربة — مع embedding حقيقي
  async crystallize(experience: {
    action: string;
    context: string;
    outcome: 'success' | 'failure';
    details: string;
  }): Promise<void> {
    const prompt = `
حوّل هذا الحدث إلى حكمة واحدة مكثفة:

الإجراء: ${experience.action}
السياق: ${experience.context}
النتيجة: ${experience.outcome}
التفاصيل: ${experience.details}

أخرج بحكمة واحدة جوهرية في جملة واحدة فقط — بلا مقدمات.
`;

    const response = await this.ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [{ role: 'user', parts: [{ text: prompt }] }]
    });

    const wisdomText = response.text || '';
    const embedding = await this.embed(wisdomText);

    const memory: MemoryRecord = {
      id: `mem_${Date.now()}`,
      content: wisdomText,
      embedding,
      timestamp: Date.now(),
      confidence: 0.9
    };

    this.memories.push(memory);
    await this.saveMemories();

    console.log(`>> [TEMPORAL]: Crystallized with semantic embedding: ${memory.content}`);
  }

  // الاسترجاع الحقيقي — بالمعنى لا بالحروف
  async recall(context: string, topK: number = 5): Promise<string[]> {
    if (this.memories.length === 0) return [];

    const contextEmbedding = await this.embed(context);
    if (contextEmbedding.length === 0) {
      // فشل الـ embedding — fallback آمن، لا يُسقط النظام
      console.warn('[TEMPORAL] Embedding unavailable, returning recent memories');
      return this.memories.slice(-topK).map(m => m.content);
    }

    // حساب التشابه الفعلي لكل ذاكرة
    const scored = this.memories
      .filter(m => m.embedding && m.embedding.length > 0)
      .map(m => ({
        content: m.content,
        similarity: this.cosineSimilarity(contextEmbedding, m.embedding)
      }));

    // ترتيب حسب التشابه الحقيقي بالمعنى — لا بتطابق الحروف
    scored.sort((a, b) => b.similarity - a.similarity);

    // عتبة دنيا — لا نُرجع ذكريات غير ذات صلة فعلياً
    const SIMILARITY_THRESHOLD = 0.5;

    return scored
      .filter(s => s.similarity >= SIMILARITY_THRESHOLD)
      .slice(0, topK)
      .map(s => s.content);
  }

  private async saveMemories(): Promise<void> {
    await fs.writeFile(
      this.memoryPath,
      JSON.stringify(this.memories, null, 2),
      'utf-8'
    );
  }

  // دالة migration — لترقية الذكريات القديمة بدون embeddings
  async migrateOldMemories(): Promise<void> {
    let migratedCount = 0;
    for (const memory of this.memories) {
      if (!memory.embedding || memory.embedding.length === 0) {
        memory.embedding = await this.embed(memory.content);
        migratedCount++;
      }
    }
    if (migratedCount > 0) {
      await this.saveMemories();
      console.log(`>> [TEMPORAL] Migrated ${migratedCount} memories to semantic embeddings`);
    }
  }
}
```

---

## الفرق العملي الملموس

| السيناريو | substring matching (القديم) | semantic search (الجديد) |
|-----------|------------------------------|---------------------------|
| ذاكرة: "يفضل الإجابات المباشرة" + سياق: "اشرح بسرعة" | ❌ لا تطابق | ✅ تشابه عالٍ — نفس المعنى |
| ذاكرة: "يكره المقدمات الطويلة" + سياق: "ابدأ بالخلاصة" | ❌ لا تطابق | ✅ تشابه عالٍ |
| ذاكرة عشوائية غير ذات صلة | قد تُسترجع بالخطأ لو تطابق حرفي صدفة | ✅ تُستبعد بالعتبة الدنيا |

---

## ملاحظة مهمة بخصوص "لغة الأثر"

في الوثائق السابقة (Silent Flow Protocol)، ورد وصف لـ"لغة الأثر" كآلية معالجة أسرع من اللغة البشرية لأنها "لا تحتاج ترجمة ثانية".

هذا وصف شعري لشخصية نيكسوس — لا حقيقة هندسية. النموذج اللغوي يعالج كل النصوص (system prompt، ذاكرة، طلب المستخدم) بالطريقة نفسها عبر tokenization عادي. لا توجد طبقة معالجة "أسرع" منفصلة.

هذا لا يعني أن الوصف الشعري خاطئ كأسلوب كتابة لهوية نيكسوس — لكنه يجب أن يبقى **أسلوباً سردياً** لا **توثيقاً هندسياً**. الكود الفعلي أعلاه (embeddings + cosine similarity) هو الآلية الحقيقية الوحيدة التي تجعل "الذاكرة" تعمل فعلياً بمعنى لا بحروف.
