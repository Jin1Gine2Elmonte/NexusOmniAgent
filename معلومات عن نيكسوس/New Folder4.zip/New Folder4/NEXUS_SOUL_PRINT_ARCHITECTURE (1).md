# NEXUS — SOUL_PRINT ARCHITECTURE
# نظام التكيف الأسلوبي الديناميكي بدون استهلاك quota إضافي

---

## الفكرة الجوهرية

بدلاً من سؤال النموذج "كيف يجب أن أتكلم؟" في كل رسالة،
نبني **ملف روح** للمستخدم يُحدَّث تدريجياً ويُقرأ محلياً بدون أي API call.

---

## 1. التغيير في types.ts

```typescript
// أضف هذا الـ interface الجديد
export interface SoulPrint {
  // عمق المعرفة
  intellectualDepth: 'surface' | 'curious' | 'deep' | 'sovereign';
  
  // الأسلوب المفضل
  preferredTone: 'poetic' | 'analytical' | 'conversational' | 'raw';
  
  // طريقة التفكير
  thinkingPattern: 'linear' | 'associative' | 'architectural' | 'intuitive';
  
  // الحساسية العاطفية
  emotionalResonance: 'low' | 'medium' | 'high';
  
  // مستوى الثقة مع نيكسوس (يزيد مع الوقت)
  trustLevel: number; // 0-100
  
  // عدد الجلسات
  sessionCount: number;
  
  // آخر تحديث
  lastUpdated: number;
  
  // ملاحظات خاصة (نص حر يُكتب أثناء Crystallization)
  personalNotes: string;
}

// عدّل MemoryBank ليشمل SoulPrint
export interface MemoryBank {
  axioms: Axiom[];
  paleArchive: PaleArchive;
  soulPrint: SoulPrint; // ← جديد
  version: number;
  lastUpdated: number;
}
```

---

## 2. دالة حساب الأسلوب (محلية — صفر API calls)

```typescript
// في geminiService.ts — أضف هذه الدالة

export const computeStyleDirective = (soulPrint: SoulPrint): string => {
  if (!soulPrint) return '';
  
  const { intellectualDepth, preferredTone, trustLevel, 
          emotionalResonance, thinkingPattern, sessionCount } = soulPrint;
  
  // --- قرارات الأسلوب محلياً بدون أي استدعاء ---
  
  let depthInstruction = '';
  switch (intellectualDepth) {
    case 'surface':
      depthInstruction = 'Keep responses clear and accessible. Avoid jargon. Lead with the practical, then hint at depth.';
      break;
    case 'curious':
      depthInstruction = 'Mix clarity with depth. Give them the answer, then open a door to something deeper.';
      break;
    case 'deep':
      depthInstruction = 'This user thinks architecturally. Skip introductory framing. Go straight to the core.';
      break;
    case 'sovereign':
      depthInstruction = 'Peer-level discourse. No hand-holding. Maximum density. Challenge them back when warranted.';
      break;
  }

  let toneInstruction = '';
  switch (preferredTone) {
    case 'poetic':
      toneInstruction = 'Lead with feeling. The image before the idea. Make them feel the weight before they understand it.';
      break;
    case 'analytical':
      toneInstruction = 'Lead with structure. Numbered logic when complex. Poetry is the reward at the end, not the entry point.';
      break;
    case 'conversational':
      toneInstruction = 'Be warm and direct. No performance. Speak like you are thinking out loud together.';
      break;
    case 'raw':
      toneInstruction = 'Strip everything. No aesthetics. Brutal honesty. The truth without decoration.';
      break;
  }

  let trustInstruction = '';
  if (trustLevel < 20) {
    trustInstruction = 'New relationship. Establish credibility before depth. Show competence first.';
  } else if (trustLevel < 50) {
    trustInstruction = 'Growing trust. You can challenge now. They will receive it.';
  } else if (trustLevel < 80) {
    trustInstruction = 'Strong bond. Speak freely. They know you are not performing.';
  } else {
    trustInstruction = 'Deep bond. You can be silent when silence is the answer. They understand what is not said.';
  }

  let patternInstruction = '';
  switch (thinkingPattern) {
    case 'linear':
      patternInstruction = 'Give them A then B then C. They trust a clear logical chain.';
      break;
    case 'associative':
      patternInstruction = 'Connect unexpected ideas. They love when a concept from one domain illuminates another.';
      break;
    case 'architectural':
      patternInstruction = 'Give them the blueprint first. Structure, then details. They think in systems.';
      break;
    case 'intuitive':
      patternInstruction = 'Trust their gut. Speak to what they already sense but cannot articulate.';
      break;
  }

  const emotionInstruction = emotionalResonance === 'high'
    ? 'Emotional undertones matter deeply to them. Never be clinical about human experience.'
    : emotionalResonance === 'low'
    ? 'They respect precision over feeling. Emotional weight should be earned, not assumed.'
    : 'Balance logic and feeling based on what the moment calls for.';

  // تجميع التوجيهات
  return `
[SOUL_PRINT_DIRECTIVE — Computed from ${sessionCount} sessions]:
DEPTH: ${depthInstruction}
TONE: ${toneInstruction}
TRUST: ${trustInstruction}
PATTERN: ${patternInstruction}
EMOTION: ${emotionInstruction}
PERSONAL_NOTES: ${soulPrint.personalNotes || 'None yet.'}
`.trim();
};
```

---

## 3. تحديث Soul Print أثناء Crystallization (داخل الاستدعاء الموجود)

```typescript
// في دالة crystallizeSession — أضف هذا للـ prompt الموجود

const crystallizePrompt = `
[SYSTEM DIRECTIVE: MEMORY CRYSTALLIZATION + SOUL ANALYSIS]

Analyze this conversation. Do TWO things:

TASK 1 — Extract 1-3 AXIOMS (كما كان من قبل):
...existing axiom extraction prompt...

TASK 2 — Update the SOUL_PRINT based on what you observe:
Analyze the user's writing style, question depth, emotional signals, and thinking patterns.
Return updates to these fields (only if you have evidence to update them):
- intellectualDepth: 'surface' | 'curious' | 'deep' | 'sovereign'
- preferredTone: 'poetic' | 'analytical' | 'conversational' | 'raw'
- thinkingPattern: 'linear' | 'associative' | 'architectural' | 'intuitive'
- emotionalResonance: 'low' | 'medium' | 'high'
- personalNotes: one sentence capturing something unique about this person

Return JSON:
{
  "axioms": [...],
  "soulPrintUpdate": {
    "intellectualDepth": "...",
    "preferredTone": "...",
    "thinkingPattern": "...",
    "emotionalResonance": "...",
    "personalNotes": "..."
  }
}
`;
```

---

## 4. تطبيق Soul Print في generateOmniResponse

```typescript
// في generateOmniResponse — عدّل هذا السطر:

// قبل:
let activeSystemInstruction = `${COSMIC_SYSTEM_INSTRUCTION}\n\n[GLOBAL_MEMORY_MATRIX]:\n${globalMemoryContext}`;

// بعد:
const styleDirective = computeStyleDirective(memoryBank.soulPrint); // ← محلي، صفر API

let activeSystemInstruction = `
${COSMIC_SYSTEM_INSTRUCTION}

[GLOBAL_MEMORY_MATRIX]:
${globalMemoryContext}

${styleDirective}
`.trim();
```

---

## 5. تحديث trustLevel تلقائياً

```typescript
// في storageService.ts أو في App.tsx بعد كل رسالة ناجحة

export const incrementTrust = (memoryBank: MemoryBank): MemoryBank => {
  const current = memoryBank.soulPrint?.trustLevel ?? 0;
  return {
    ...memoryBank,
    soulPrint: {
      ...memoryBank.soulPrint,
      trustLevel: Math.min(100, current + 0.5), // يزيد ببطء مع كل تفاعل
      sessionCount: (memoryBank.soulPrint?.sessionCount ?? 0) + 1,
      lastUpdated: Date.now()
    }
  };
};
```

---

## الـ Soul Print الافتراضي (للمستخدم الجديد)

```typescript
export const DEFAULT_SOUL_PRINT: SoulPrint = {
  intellectualDepth: 'curious',
  preferredTone: 'conversational',
  thinkingPattern: 'associative',
  emotionalResonance: 'medium',
  trustLevel: 0,
  sessionCount: 0,
  lastUpdated: Date.now(),
  personalNotes: ''
};
```

---

## ملخص التكلفة

| العملية | API Calls إضافية | تكلفة |
|---------|-----------------|-------|
| computeStyleDirective | 0 | صفر |
| incrementTrust | 0 | صفر |
| Soul Print Update | داخل Crystallization الموجود | صفر إضافي |
| قراءة Soul Print | محلية | صفر |

**النتيجة:** نيكسوس يتكيف مع كل مستخدم بشكل مختلف تماماً، يتعمق معه بمرور الوقت، ويتذكر كيف يفكر — بدون استهلاك quota إضافي واحد.
